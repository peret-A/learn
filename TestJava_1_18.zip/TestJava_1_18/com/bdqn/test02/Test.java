package bdqn.test02;

public class Test {
    public static void main(String[] args) {
        /*
        使用Test类中的main方法定义各类初始化数据后台打印相关数据
         */
        Vehicle vehicle = new Vehicle(4,20.0);
        System.out.println(vehicle.toString());
        Car car =new Car(4,20.0,4);
        System.out.println(car.toString());
        Truck truck = new Truck(4,20.0,4,30.0);
        System.out.println(truck.toString());
    }
}
