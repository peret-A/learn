package bdqn.test02;

public class Truck extends Car{
    /*
    卡车类Truck是Car类的子类，其中包含的属性有载重量payload。
     */
    private double payload;

    @Override
    public String toString() {
        return "卡车{" +
                "有载重量=" + payload +
                '}';
    }

    public double getPayload() {
        return payload;
    }

    public void setPayload(double payload) {
        this.payload = payload;
    }

    public Truck(int wheels, double weight, int loader, double payload) {
        super(wheels, weight, loader);
        this.payload = payload;
    }

    public Truck() {
    }
}
