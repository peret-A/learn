package bdqn.test07;

public class Test {
    public static void main(String[] args) {
        Driver driver = new Driver();
        Car car=new Car();
        Bus bus=new Bus();
        Train train=new Train();
        driver.drive(car);
        driver.drive(bus);
        driver.drive(train);
    }
}
