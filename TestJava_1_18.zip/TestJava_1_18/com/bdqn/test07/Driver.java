package bdqn.test07;

public class Driver {
    /*
    07：根据下图写出“司机”类。（主要体现方法的重载）
     */
    public void drive(Car car){
        System.out.println("轿车: 启动、驾驶");
    }
    public void drive(Bus bus){
        System.out.println("巴士:等待乘客上车、启动、行驶、到站停车、....");
    }
    public void drive(Train train){
        System.out.println("火车:正点发车、行驶、到站停牛、...");
    }

}
