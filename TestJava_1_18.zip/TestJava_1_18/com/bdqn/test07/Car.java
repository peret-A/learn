package bdqn.test07;

public class Car {

}
