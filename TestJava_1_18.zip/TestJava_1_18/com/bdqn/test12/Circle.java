package bdqn.test12;

public class Circle extends Graphics{
    private String center;
    private double radius;

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public String getCenter() {
        return center;
    }

    public void setCenter(String center) {
        this.center = center;
    }

    public Circle() {
    }

    public Circle(String center, double radius) {
        this.center = center;
        this.radius = radius;
    }
// 圆形类：包含圆心和半径，重写求周长和求面积的方法
    public double girth(){
        return Math.PI*radius*2;
    }
    public double area(){
        return Math.PI*radius*radius;
    }
}
