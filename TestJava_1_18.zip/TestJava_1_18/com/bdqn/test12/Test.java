package bdqn.test12;

public class Test {
    public static void main(String[] args) {
        Circle circle=new Circle("(2,2)",2);
        System.out.println("圆的周长: "+circle.girth());
        System.out.println("圆的面积: "+circle.area());
        Rectangle rectangle=new Rectangle(2,3);
        System.out.println("长方形的周长: " + rectangle.girth());
        System.out.println("长方形的面积: " + rectangle.area());

    }
}
