package bdqn.test12;

public class Graphics {
    /*
    12：定义一个图形类和（子类）圆形类、矩形类
    图像类：有求周长和求面积和显示图形信息的功能。
    圆形类：包含圆心和半径，重写求周长和求面积的方法
    矩形类：包含长和宽，重写求周长和求面积的方法
     */
    public double girth(){
        return 0.0;
    }
    public double area(){
        return 0.0;
    }

}
