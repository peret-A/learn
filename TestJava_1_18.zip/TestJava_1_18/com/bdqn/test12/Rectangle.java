package bdqn.test12;

public class Rectangle extends Graphics{
    /*
    矩形类：包含长和宽，重写求周长和求面积的方法
     */
    private double lenght;
    private double wight;

    public double getLenght() {
        return lenght;
    }

    public void setLenght(double lenght) {
        this.lenght = lenght;
    }

    public double getWight() {
        return wight;
    }

    public void setWight(double wight) {
        this.wight = wight;
    }

    public Rectangle() {
    }

    public Rectangle(double lenght, double wight) {
        this.lenght = lenght;
        this.wight = wight;
    }
    public double girth(){
        return lenght*2+wight*2;
    }
    public double area(){
        return lenght*wight;
    }
}
