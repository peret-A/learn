package bdqn.test09;

public class Dog extends Pet{
    public Dog(String name, int age) {
        super(name, age);
    }

    public Dog() {
    }

    /*
        Dog继承 Pet类所有并且增加一个自己的特有方法police() 警戒并且叫声是汪汪
         */
    public void police(){
        System.out.println("动物: " + super.getName() + "， 年龄: " + super.getAge() + "警戒并且叫声是汪汪");
    }
}
