package bdqn.test09;

public class Test {
    public static void main(String[] args) {
        Cat cat = new Cat("小明",18);
        cat.eat();
        cat.drink();
        cat.shout();
        cat.climbTree();
        Dog dog=new Dog("小黑",20);
        dog.eat();
        dog.drink();
        dog.shout();
        dog.police();
    }
}
