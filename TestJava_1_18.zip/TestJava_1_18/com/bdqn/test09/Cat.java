package bdqn.test09;

public class Cat extends Pet{
    public Cat() {
    }

    public Cat(String name, int age) {
        super(name, age);
    }

    /*
                Cat继承 Pet类所有并且增加一个自己的特有方法climbTree() 爬树并且叫声是喵喵
             */
    public void climbTree(){
        System.out.println("动物: " + super.getName() + "， 年龄: " + super.getAge() + "爬树并且叫声是喵喵");
    }
}
