package bdqn.test09;

public class Pet {
    /*
    09：宠物类叫Pet（父类） ；
	属性有name 和 age；
	行为有吃 eat(); 喝 drink(); 叫声shout();
    子类 Cat 和 Dog
    Cat继承 Pet类所有并且增加一个自己的特有方法climbTree() 爬树并且叫声是喵喵
    Dog继承 Pet类所有并且增加一个自己的特有方法police() 警戒并且叫声是汪汪
     */
    private String name;
    private int age;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public Pet(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public Pet() {
    }

    //行为有吃 eat(); 喝 drink(); 叫声shout();
    public void eat(){
        System.out.println("动物: " + name + "， 年龄: " + age + "正在吃");
    }
    public void drink(){
        System.out.println("动物: " + name + "， 年龄: " + age + "正在喝");
    }
    public void shout(){
        System.out.println("动物: " + name + "， 年龄: " + age + "正在叫");
    }
}
