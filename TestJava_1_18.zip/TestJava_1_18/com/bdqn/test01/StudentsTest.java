package bdqn.test01;

public class StudentsTest {
    public static void main(String[] args) {
        Students students =new Students("小明",65,78,21);
        students.toString();
        //要求可以求学生的总分、平均分、最高分、最低分。
        System.out.println("总分 "+students.sumScore());
        System.out.println("平均分 "+students.avgScore());
        System.out.println("最高分 "+students.maxScore());
        System.out.println("最低分 "+students.minScore());
    }
}
