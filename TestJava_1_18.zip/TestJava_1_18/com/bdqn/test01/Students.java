package bdqn.test01;

public class Students {
    /*
    01：要求设计一个学生类。
    1：属性有：姓名、Java成绩、android成绩、mysql成绩
    2：所有属性要求使用private修饰。
    3：为每个属性设置setter和getter方法
    4：添加有为全部属性赋值的构造方法
    5：有输出一个完整学生信息的方法
    6：要求可以求学生的总分、平均分、最高分、最低分。
     */
    private String name;

    private double score_java;
    private double score_android;
    private double score_mysql;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getScore_java() {
        return score_java;
    }

    public void setScore_java(double score_java) {
        this.score_java = score_java;
    }

    public double getScore_android() {
        return score_android;
    }

    public void setScore_android(double score_android) {
        this.score_android = score_android;
    }

    public double getScore_mysql() {
        return score_mysql;
    }

    public void setScore_mysql(double score_mysql) {
        this.score_mysql = score_mysql;
    }

    public Students(String name, double score_java, double score_android, double score_mysql) {
        this.name = name;
        this.score_java = score_java;
        this.score_android = score_android;
        this.score_mysql = score_mysql;
    }

    public Students() {
    }

    //有输出一个完整学生信息的方法

    @Override
    public String toString() {
        return "学生信息{" +
                "学生名字='" + name + '\'' +
                ", java成绩=" + score_java +
                ", android成绩=" + score_android +
                ", mysql成绩=" + score_mysql +
                '}';
    }

    //要求可以求学生的总分、平均分、最高分、最低分。

    public double sumScore(){
        return score_android+score_java+score_mysql;
    }
    //平均分
    public double avgScore(){
        return sumScore()/3;
    }
    //最高分
    public double maxScore() {
       return score_mysql > score_java ?
                (score_mysql >score_android?score_mysql:score_android):
                (score_java>score_android?score_java:score_android);
    }

    //最小分
    public double minScore(){
        return score_mysql < score_java ?
                (score_mysql < score_android?score_mysql:score_android):
                (score_java < score_android?score_java:score_android);
    }
}
