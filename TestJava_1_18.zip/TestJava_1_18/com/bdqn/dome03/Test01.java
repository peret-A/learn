package bdqn.dome03;

public class Test01 {
    static private int num;

    public static void main(String[] args) {
        Test01.num=1;
        while (Test01.num<=100){
            System.out.println("投票" + Test01.num);
            Test01.num++;

        }
    }
}
