package bdqn.test11;

public class Nightingale extends Bird{
    public Nightingale(){
        referenceCount++;
    }
    public static void main(String[] args){
        System.out.println("Bird:" + Bird.referenceCount);
        Nightingale nightingale=new Nightingale();
        System.out.println("Nightingale:" + Bird.referenceCount);
    }
}
