package bdqn.test11;

public class Bird {
    /*
    11：已有Bird类的定义如下：

有子类Nightingale的定义如下，请写出它的输出结果。

分析以上程序的输出结果是什么？为什么？
     */
    protected static int referenceCount = 0;
    public Bird(){
        referenceCount++;
    }
    public void fly(){

    }
    static int getReCount(){
        return referenceCount;
    }
}
