package bdqn.test08;

public class Test {
    public static void main(String[] args) {
        Student student1= new Student("小明",18);
        student1.print();
        Student student2=new Student("小红",35,"女","计算机");
        student2.print();
    }
}
