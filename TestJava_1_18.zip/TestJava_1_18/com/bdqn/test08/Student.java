package bdqn.test08;

public class Student {
    /*
    08：编写一个类Student，代表学员，要求：
    （1）具有属性：姓名、年龄、性别、专业。
    （2）具有方法：自我介绍，负责输出该学员的姓名、年龄、性别以及专业。
    （3）具有两个带参构造方法：第一个构造方法中，设置学员的性别为男、专业为3g，其余属性的值由参数给定；
    第二个构造方法中，所有属性的值都由参数给定
    编写测试类StudentTest进行测试，分别以两种方式完成对两个Student对象的初始化工作，并分别调用它们的自我介绍方法，
    看看输出是否正确。
     */
    private String name;
    private int age;
    private String gender;
    private String dept;

    public Student(String name, int age) {
        this.name = name;
        this.age = age;
        this.gender="男";
        this.dept="3g";
    }

    public Student(String name, int age, String gender, String dept) {
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.dept = dept;
    }

    public Student() {
    }

    //具有方法：自我介绍，负责输出该学员的姓名、年龄、性别以及专业。
    public void print(){
        System.out.println("学生的名字: " + name + ", 年龄: " + age + ", 性别: " + gender + ", 专业: " + dept);
    }
}
