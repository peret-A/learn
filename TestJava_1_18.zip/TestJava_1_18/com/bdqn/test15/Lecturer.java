package bdqn.test15;

public class Lecturer extends Teacher{
    public Lecturer() {
    }

    public Lecturer(String name, int age, String post, double salary) {
        super(name, age, post, salary);
    }

    public void introduce(){
        System.out.println("教师名字: " + super.getName() + ", 教师年龄: " + super.getAge() + ", 职称: " + super.getPost()
                + ", 基本工资: " + super.getSalary()*Teacher.levela+", 部门: "+department);

    }
}
