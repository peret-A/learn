package bdqn.test15;

public class Teacher {
    /*
    15：编写老师类
    （1）要求有属性“姓名name”，“年龄age”，“职称post”，“基本工资salary”。
    （2）设置4个静态常量：“部门department”值为“baway”，“工资级别levela ,levelb,levelc”初始值分别为1.1,1.2,1.3。
    （3）编写业务方法， introduce（），实现输出一个教师的信息。
    （4）：编写教师类的三个子类：
    类、副教授类、讲师类。工资级别分别为：教授为1.3、副教授为1.2、讲师类1.1。
    在三个子类里面都重写父类的introduce()方法。
    （5）定义并初始化一个老师对象，调用业务方法，实现对象基本信息的后台打印。
     */
    private String name;
    private int age;
    private String post;

    public Teacher() {
    }

    public Teacher(String name, int age, String post, double salary) {
        this.name = name;
        this.age = age;
        this.post = post;
        this.salary = salary;
    }

    private double salary;
    final static String department="baway";
    final static double levela=1.1;
    final static double levelb=1.2;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getPost() {
        return post;
    }

    public void setPost(String post) {
        this.post = post;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    final static double levelc=1.3;
//（3）编写业务方法， introduce（），实现输出一个教师的信息。
    public void introduce(){
        System.out.println("教师名字: " + name + ", 教师年龄: " + age + ", 职称: " + post + ", 基本工资: " + salary+", 部门: "+department);

    }
}
