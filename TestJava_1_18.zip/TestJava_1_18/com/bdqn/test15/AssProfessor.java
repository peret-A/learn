package bdqn.test15;

public class AssProfessor extends Teacher{
    /*
        类、副教授类、讲师类。工资级别分别为：教授为1.3、副教授为1.2、讲师类1.1。
    在三个子类里面都重写父类的introduce()方法。
     */

    public AssProfessor() {
    }

    public AssProfessor(String name, int age, String post, double salary) {
        super(name, age, post, salary);
    }

    public void introduce(){
        System.out.println("教师名字: " + super.getName() + ", 教师年龄: " + super.getAge() + ", 职称: " + super.getPost()
                + ", 基本工资: " + super.getSalary()*Teacher.levelb+", 部门: "+department);

    }
}
