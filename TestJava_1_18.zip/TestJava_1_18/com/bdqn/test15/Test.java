package bdqn.test15;

public class Test {
    /*
        （5）定义并初始化一个老师对象，调用业务方法，实现对象基本信息的后台打印。
         （1）要求有属性“姓名name”，“年龄age”，“职称post”，“基本工资salary”。
     */
    public static void main(String[] args) {
        Professor professor=new Professor("张三",18,"教授",3000);
        professor.introduce();
        AssProfessor assProfessor=new AssProfessor("小明",35,"副教授",3000);
        assProfessor.introduce();
        Lecturer lecturer=new Lecturer("小红",65,"讲师",1000);
        lecturer.introduce();
    }
}
