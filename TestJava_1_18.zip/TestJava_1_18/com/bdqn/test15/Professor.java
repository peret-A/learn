package bdqn.test15;

public class Professor extends Teacher{
    public Professor(String name, int age, String post, double salary) {
        super(name, age, post, salary);
    }

    public Professor() {
    }



    // 在三个子类里面都重写父类的introduce()方法。
    public void introduce(){
        System.out.println("教师名字: " + super.getName() + ", 教师年龄: " + super.getAge() + ", 职称: " + super.getPost()
                + ", 基本工资: " + super.getSalary()*Teacher.levelc+", 部门: "+department);

    }

}
