package bdqn.test06;

public class test {
    public static void main(String[] args) {
        /*
        编写测试类Book3Test进行测试：
 	分别以两种方式完成对两个Book3对象的初始化工作，并分别调用它们的detail方法，看看输出是否正确
         */
        Book3 book3 =new Book3("奥特曼",200);
        book3.detail();
        Book3 book31 = new Book3("安徒生",300,"科学");
        book31.detail();
    }
}
