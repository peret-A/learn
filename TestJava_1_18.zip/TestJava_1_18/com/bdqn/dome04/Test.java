package bdqn.dome04;

public class Test {
    public static void main(String[] args) {
        Dog dog=new Dog("小明",15,"red","品种");
        dog.print();
    }
}
