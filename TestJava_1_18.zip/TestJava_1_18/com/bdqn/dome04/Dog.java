package bdqn.dome04;

public class Dog extends Pet{
    private String variety;

    public String getVariety() {
        return variety;
    }

    public void setVariety(String variety) {
        this.variety = variety;
    }

    public Dog(String name, int age, String color, String variety) {
        super(name, age, color);
        this.variety = variety;
    }

    public Dog() {
    }
}
