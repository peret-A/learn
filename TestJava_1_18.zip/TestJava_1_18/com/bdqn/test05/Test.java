package bdqn.test05;

public class Test {
    public static void main(String[] args) {
        /*
         	编写测试类Book2Test进行测试：初始化一个Book2对象，并调用该Book2对象的detail方法，看看输出是否正确
         */
        Book2 book2=new Book2("奥特曼",178);
        book2.Sdetail();
    }
}
