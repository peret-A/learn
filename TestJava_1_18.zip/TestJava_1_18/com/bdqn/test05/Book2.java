package bdqn.test05;

public class Book2 {
    /*
     05：编写一个类Book2，代表教材：
 	具有属性：名称（title）、页数（pageNum），其中页数不能少于200页，否则输出错误信息，并赋予默认值200
 	具有方法：Sdetail，用来在控制台输出每本教材的名称和页数
 	具有带参数的构造方法：用来完成对象的初始化工作，并在构造方法中完成对页数的最小值限制
 	编写测试类Book2Test进行测试：初始化一个Book2对象，并调用该Book2对象的detail方法，看看输出是否正确
     */
    private String title;
    private double pageNum;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public double getPageNum() {
        return pageNum;
    }

    public void setPageNum(double pageNum) {
        if(pageNum<200){
            System.out.println("输出错误信息，并赋予默认值200");
            pageNum=200;
        }
        this.pageNum = pageNum;
    }

    public Book2(String title, double pageNum) {
        this.title = title;
        setPageNum(pageNum);
    }

    public Book2() {
    }
    public void Sdetail(){
        // 3)具有方法:detail，用来在控制台输出每本教材的名称和页数
        System.out.println("名称:" + title + "，页数:" + pageNum);
    }
}
