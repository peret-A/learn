package bdqn.dome01;
// protected 不能修饰类
//protected class Element04 {
//}
