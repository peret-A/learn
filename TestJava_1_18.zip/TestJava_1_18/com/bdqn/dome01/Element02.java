package bdqn.dome01;

class Element02 {
}
