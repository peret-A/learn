package bdqn.dome01;

public class Test01 {
    public static void main(String[] args) {
//        Element01 element01=new Element01();
//        //name 被public修饰的 在同一包下的不同类中可以随意使用
//        element01.name="fan";
//        //age 被default修饰的 在同一包下的不同类中可以随意使用
//        element01.age=18;
//        //gender 被protected修饰的 在同一包下的不同类中可以随意使用
//        element01.gender="男";
//        //tel 被private修饰的 在同一包下的不同类中不可以使用
////        element01.tel="1214";
        // 被默认修饰的类可以在同一个包不同类使用
        Element02 element02 =new Element02();
    }
}
