package bdqn.dome01;

public class Element01 {
    public String name;
    int age;
    protected String gender;
    private String tel;

    public static void main(String[] args) {
        Element01 element01=new Element01();
        //name 被public修饰的 在同一包下的同一类中可以随意使用
        element01.name="fan";
        //age 被default修饰的 在同一包下的同一类中可以随意使用
        element01.age=18;
        //gender 被protected修饰的 在同一包下的同一类中可以随意使用
        element01.gender="男";
        //tel 被private修饰的 在同一包下的同一类中可以随意使用
        element01.tel="1214";


    }
}
