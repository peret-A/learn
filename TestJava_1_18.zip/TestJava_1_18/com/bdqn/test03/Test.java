package bdqn.test03;

public class Test {
    public static void main(String[] args) {
        //    4)编写测试类BookTest进行测试：为Book对象的属性赋予初始值，并调用Book对象的detail方法，看看输出是否正确
        Book book=new Book();
        book.setTitle("奥特曼");
        book.setPageNum(189);
        book.detail();
    }
}
