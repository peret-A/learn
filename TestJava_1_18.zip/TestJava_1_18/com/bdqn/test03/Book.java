package bdqn.test03;

public class Book {
    /*
    03：请通过代码封装，实现如下需求：
    编写一个类Book，代表教材:
    1)具有属性：名称（title）、页数（pageNum），其中页数不能少于200页，否则输出错误信息，并赋予默认值200
    2)每个属性要求使用private修饰，并且为各属性设置赋值和取值方法
    3)具有方法:detail，用来在控制台输出每本教材的名称和页数
    4)编写测试类BookTest进行测试：为Book对象的属性赋予初始值，并调用Book对象的detail方法，看看输出是否正确
     */
    private String title;
    private double pageNum;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public double getPageNum() {
        return pageNum;
    }

    public void setPageNum(double pageNum) {
        if(pageNum<200){
            System.out.println("输出错误信息，并赋予默认值200");
            pageNum=200;
        }
        this.pageNum = pageNum;
    }

    public Book(String title, double pageNum) {
        this.title = title;
        setPageNum(pageNum);
    }

    public Book() {
    }
    public void detail(){
        // 3)具有方法:detail，用来在控制台输出每本教材的名称和页数
        System.out.println("名称:" + title + "，页数:" + pageNum);
    }
}
