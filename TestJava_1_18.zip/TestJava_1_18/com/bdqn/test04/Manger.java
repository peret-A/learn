package bdqn.test04;

public class Manger extends Employee{
    public Manger() {
    }

    public Manger(double salary, int day) {
        super(salary, day);
    }

    //部门经理工资=1000+单日工资*天数*等级（1.2）。
    //定义并初始化普通员工对象，调用打印工资方法输入工资，定义并初始化部门经理对象，调用打印工资方法输入工资
    public void print(){
        System.out.println("单日工资: " + super.getSalary() + " 天数: " +super.getDay() + " 等级: " + super.getLevel()*1.2);
        System.out.println("部门经理工资: " +super.getSalary() * super.getDay() * super.getLevel()*1.2);
    }
}
