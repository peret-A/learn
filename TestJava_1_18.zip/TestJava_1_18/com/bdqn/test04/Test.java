package bdqn.test04;

public class Test {
    public static void main(String[] args) {
        Employee employee=new Employee(200,20);
        Employee.setLevel(1);
        employee.print();
        Manger manger=new Manger(300,20);
        manger.print();
    }

}
