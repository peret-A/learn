package bdqn.test10;

import bdqn.test04.Employee;

public class Washer extends Electrical {
    public Washer(double current, double voltage) {
        super(current, voltage);
    }

    public Washer() {
    }

    /*
        洗衣机还有方法：wash（）；
         */
    public void wash(){
        System.out.println("洗衣机");
    }

}
