package bdqn.test10;

public class Lamp extends Electrical{
    public Lamp() {
    }

    public Lamp(double current, double voltage) {
        super(current, voltage);
    }

    /*
        电灯的特有方法如light（）；
         */
    public void Light(){
        System.out.println("电灯");
    }
}
