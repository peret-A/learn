package bdqn.test10;

public class Test {
    public static void main(String[] args) {
        Tv tv=new Tv(20.0,20.0);
        tv.open();
        tv.close();
        tv.display();
        Washer washer=new Washer(20.0,20.0);
        washer.open();
        washer.close();
        washer.wash();
        Lamp lamp =new Lamp(20,20.0);
        lamp.open();
        lamp.close();
        lamp.Light();
    }


}
