package bdqn.test10;

import bdqn.test04.Employee;

public class Tv extends Electrical {
    /*
    电视除还有方法：display（）；
     */



    public Tv() {
    }

    public Tv(double current, double voltage) {
        super(current, voltage);
    }

    public void display(){
        System.out.println("电视除");
    }
}
