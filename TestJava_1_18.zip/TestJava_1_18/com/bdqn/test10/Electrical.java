package bdqn.test10;

public class Electrical {
    /*
    10：父类：家用电器，属性有电流、电压；行为有开open（），关close（）
    子类：电视除还有方法：display（）；
    洗衣机还有方法：wash（）；
    电灯的特有方法如light（）；
     */
    private double current;
    private double voltage;

    public double getCurrent() {
        return current;
    }

    public void setCurrent(double current) {
        this.current = current;
    }

    public double getVoltage() {
        return voltage;
    }

    public void setVoltage(double voltage) {
        this.voltage = voltage;
    }

    public Electrical(double current, double voltage) {
        this.current = current;
        this.voltage = voltage;
    }

    public Electrical() {
    }
    //行为有开open（），关close（）
    public void open(){
        System.out.println("电流" + current + "、电压；" + voltage+"开电器");
    }
    public void close(){
        System.out.println("电流" + current + "、电压；" + voltage+"关电器");
    }

}
