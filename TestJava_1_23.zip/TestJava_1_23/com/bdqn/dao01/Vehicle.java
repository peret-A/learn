package bdqn.dao01;
// 定义抽象类 车
//属性 品牌 车牌  租金
public abstract class Vehicle {
private String brand;
private String licensePlate;

    public Vehicle(String brand, String licensePlate, double rent) {
        this.brand = brand;
        this.licensePlate = licensePlate;
        this.rent = rent;
    }

    public String getLicensePlate() {
        return licensePlate;
    }

    public void setLicensePlate(String licensePlate) {
        this.licensePlate = licensePlate;
    }

    private double rent;

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }



    public double getRent() {
        return rent;
    }

    public void setRent(double rent) {
        this.rent = rent;
    }

    public Vehicle() {
    }


    //折扣
    public abstract double discount(int days);
}
