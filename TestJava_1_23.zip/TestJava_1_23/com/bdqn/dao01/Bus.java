package bdqn.dao01;
//继承vehicle类
//特殊属性： 载人量
//重写方法： 计算租金
public class Bus extends Vehicle{
    public int getMannedCapacity() {
        return mannedCapacity;
    }

    public void setMannedCapacity(int mannedCapacity) {
        this.mannedCapacity = mannedCapacity;
    }

    public Bus(String brand, String licensePlate, double rent, int mannedCapacity) {
        super(brand, licensePlate, rent);
        this.mannedCapacity = mannedCapacity;
    }

    public Bus() {
    }

    private int mannedCapacity;
    @Override
    public double discount(int days) {
        if(days>=3&&days<=6){
            return this.getRent()*0.9*days;
        }else if(days>=7&&days<30){
            return this.getRent()*0.8*days;
        }else if(days>=30&&days<150){
            return this.getRent()*0.7*days;
        }else if(days>=150){
            return this.getRent()*0.6*days;
        }else {
            return this.getRent()*days;
        }

    }
}
