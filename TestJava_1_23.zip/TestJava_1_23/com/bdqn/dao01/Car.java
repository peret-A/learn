package bdqn.dao01;
// 继承Vehicle类
//特殊属性： 类型
//特殊方法： 计算租金
public class Car extends Vehicle{
private String type;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }



    public Car() {
    }

    public Car(String brand, String licensePlate, double rent, String type) {
        super(brand, licensePlate, rent);
        this.type = type;
    }

    @Override
    public double discount(int days) {
        if(days>7&&days<=30){
            return 0.9*this.getRent()*days;
        }else if(days>30&&days<=150){
            return 0.8*this.getRent()*days;
        }else if(days>150) {
            return 0.7 * this.getRent()*days;
        }else {
            return this.getRent()*days;
        }
    }
}
