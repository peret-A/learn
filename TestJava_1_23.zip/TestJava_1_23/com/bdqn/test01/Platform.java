package bdqn.test01;

import bdqn.dao01.Bus;
import bdqn.dao01.Car;
import bdqn.dao01.Vehicle;

// 作为租车的交易平台
// 方法: 初始化现有车辆 根据用户所选的进行发送
public class Platform {
    Vehicle[] vehicles;
    public Platform() {
        this.vehicles =new Vehicle[8];
        this.vehicles[0] = new Car("宝马","京N28588",800,"X6");
        this.vehicles[1] = new Car("宝马","京CNY3284",600,"550i");
        this.vehicles[2] = new Car("别克","京NT37465",300,"林萌大道");
        this.vehicles[3] = new Car("别克","京NT96968",600,"GL8");
        this.vehicles[4] = new Bus("金杯","京6566754",800,16);
        this.vehicles[5] = new Bus("金龙","京8696997",800,16);
        this.vehicles[6] = new Bus("金杯","京9696996",1500,34);
        this.vehicles[7] = new Bus("金龙","京9696998",1500,34);
    }
    //打印租金
    public void info(Vehicle vehicle,int days){
        //先锁定要组的车子
        if(vehicle instanceof Car){
            for (int i = 0; i < 4; i++) {
                Car car  = (Car) this.vehicles[i];
                if(((Car) vehicle).getType().equals(car.getType())){
                    System.out.println("租金为: "+car.discount(days));
                }
            }
        }else if(vehicle instanceof  Bus){
            for (int i = 4; i < 8; i++) {
                Bus bus = (Bus) this.vehicles[i];
                if(vehicle.getBrand().equals(bus.getBrand())&&bus.getMannedCapacity()==((Bus) vehicle).getMannedCapacity()){
                    System.out.println("租金为: "+bus.discount(days));
                }
            }
        }
    }
}
