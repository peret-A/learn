package bdqn.test01;

import bdqn.dao01.Bus;
import bdqn.dao01.Car;
import bdqn.dao01.Vehicle;

import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
//        System.out.println( 1/0);
//
//        long time1 = System.currentTimeMillis();
//        int sum=0;
//        for (int i = 0; i < 1000000000; i++) {
//            for (int j = 0; j < 10000000; j++) {
//                sum+=i;
//            }
//        }
//
//        long time2 = System.currentTimeMillis();
//        System.out.println(time2-time1);

        Platform platform =new Platform();

        System.out.println("1. 汽车 2. 公交");
        //创建Scanner对象
        Scanner scanner=new Scanner(System.in);
        int index =scanner.nextInt();
        //创建要选的车子
        if( index == 1 ){
            Car car =new Car();
            System.out.println("品牌: 1. 宝马 2. 别克");
            index = scanner.nextInt();
            if(index == 1){
                car.setBrand("宝马");
                System.out.println("类型: 1. X6 2. 500i");
                index = scanner.nextInt();
                if(index == 1) car.setType("X6");
                else car.setType("500i");
            }else{
                car.setBrand("别克");
                System.out.println("类型: 1. 林萌大道 2. GL8");
                index = scanner.nextInt();
                if(index == 1) car.setType("林萌大道");
                else car.setType("GL8");
            }
            //输入要组的天数
            System.out.print("输入要组的天数: ");
            int days =scanner.nextInt();
            platform.info(car,days);

        }else {
            Bus bus = new Bus();
            System.out.println("品牌: 1. 金杯 2. 金龙");
            index = scanner.nextInt();
            if(index == 1){
                bus.setBrand("金杯");
                System.out.println("载人量: 1. 16 2. 34");
                index = scanner.nextInt();
                if(index == 1) bus.setMannedCapacity(16);
                else bus.setMannedCapacity(34);
            }else{
                bus.setBrand("金龙");
                System.out.println("载人量: 1. 16 2. 34");
                index = scanner.nextInt();
                if(index == 1) bus.setMannedCapacity(16);
                else bus.setMannedCapacity(34);
            }
            //输入要组的天数
            System.out.print("输入要组的天数: ");
            int days =scanner.nextInt();
            platform.info(bus,days);
        }



    }
}
