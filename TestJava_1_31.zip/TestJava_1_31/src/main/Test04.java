package main;

import java.io.*;

public class Test04 {
    public static void main(String[] args) {
        //准备文件
        File fileRead =new File("pet.template");
        File fileWrite = new File("pet.txt");

        //准备读取写入流
        InputStream inputStream=null;
        Reader reader=null;
        BufferedReader bufferedReader=null;
        OutputStream outputStream=null;
        Writer out=null;
        BufferedWriter bufferedWriter=null;
        try {
            //读取流
            inputStream =new FileInputStream(fileRead);
            reader =new InputStreamReader(inputStream,"utf-8");
            bufferedReader =new BufferedReader(reader);

            //写入流
            outputStream =new FileOutputStream(fileWrite);
            out =new OutputStreamWriter(outputStream,"utf-8");
            bufferedWriter =new BufferedWriter(out);

            //读取文件
            String data = bufferedReader.readLine();
            bufferedWriter.write(data+"\n");
            //分析数据 错误点：string类是不可修改的 要将数据在重新复制.
            data= data.replace("前","后");
            data= data.replace("｛name｝","欧欧");
            data= data.replace("{type}","狗狗");
            data= data.replace("｛master｝","李伟");
            //写入文件
            bufferedWriter.write(data);
            //刷新
            bufferedWriter.flush();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            //关闭流
            if(bufferedWriter!=null){
                try {
                    bufferedWriter.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if(out!=null){
                try {
                    out.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if(outputStream!=null){
                try {
                    outputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if(bufferedReader!=null){
                try {
                    bufferedReader.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if(reader!=null){
                try {
                    reader.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if(inputStream!=null){
                try {
                    inputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
}
