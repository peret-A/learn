package main;

import java.io.*;

public class Test06 {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        OutputStream outputStream =new FileOutputStream("student.txt");
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);

        Student student =new Student("小明",25,"男");
        objectOutputStream.writeObject(student);
        objectOutputStream.close();
        outputStream.close();

//        InputStream inputStream =new FileInputStream("student.txt");
//        ObjectInputStream objectInputStream =new ObjectInputStream(inputStream);
//        Object object = objectInputStream.readObject();
//        Student student1 = (Student) object;
//        System.out.println(student1);

    }

}
