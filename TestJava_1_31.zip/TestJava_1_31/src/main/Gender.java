package main;

public enum Gender {
    男,女
}
