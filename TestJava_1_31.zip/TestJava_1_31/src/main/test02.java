package main;

import java.io.*;

public class test02 {
    public static void main(String[] args) throws IOException {
        File file =new File("ab.txt");
        FileWriter fileWriter =new FileWriter(file,true);
        fileWriter.write('s');

        fileWriter.flush();
        fileWriter.close();
    }
}
