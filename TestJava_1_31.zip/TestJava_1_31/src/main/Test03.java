package main;

import java.io.*;

public class Test03 {
    public static void main(String[] args)  {
        File file =new File("ab.txt");
        OutputStream outputStream = null;
        Writer out=null;
        BufferedWriter bufferedWriter=null;
        try {
            outputStream = new FileOutputStream(file,true);
            out =new OutputStreamWriter(outputStream,"utf-8");
            bufferedWriter =new BufferedWriter(out);


            bufferedWriter.write("\n aadada");
            bufferedWriter.newLine();
            bufferedWriter.write("jadaj");
            bufferedWriter.flush();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }finally {
            if(bufferedWriter!=null){
                try {
                    bufferedWriter.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if(out!=null){
                try {
                    out.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if(outputStream!=null){
                try {
                    outputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }




    }
}
