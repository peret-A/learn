package main;

import java.io.*;

public class Test05 {
    public static void main(String[] args) throws IOException {
        InputStream inputStream = new FileInputStream("R-C.jpg");
        DataInputStream dataInputStream =new DataInputStream(inputStream);
        OutputStream outputStream = new FileOutputStream("my.jpg");
        DataOutputStream dataOutputStream =new DataOutputStream(outputStream);
        int nums;
        while ((nums=dataInputStream.read())!=-1){
            dataOutputStream.write(nums);
        }

        dataOutputStream.flush();
        dataOutputStream.close();
        outputStream.close();
        dataInputStream.close();
        inputStream.close();
    }
}
