package main;

import java.io.*;

public class Test01 {
    public static void main(String[] args) throws IOException {
        File file =new File("ab.txt");
        OutputStream outputStream =new FileOutputStream(file,true);
        OutputStreamWriter outputStreamWriter =new OutputStreamWriter(outputStream,"utf-8");

//        outputStreamWriter.write(65);
        outputStreamWriter.write("fandawdawda",3,4);
        outputStreamWriter.flush();
        outputStreamWriter.close();
        outputStream.close();

    }
}
