# # 基础类型注解
# import json
# import random
#
# var_1: int = 30
# var_2: str = "hello"
# var_3: bool = True
# var_4: float = 12.5
#
#
# # 类对象类型注解
# # 先定义一个类
# class Student:
#     pass
#
#
# stu: Student = Student()
#
# # 基础容器注解
# my_list: list = [1, 3, "k"]
# my_tuple: tuple = (1, 2, 3, "a")
# my_str: str = "dawda"
# my_set: set = {1, 2, "d"}
# my_dict: dict = {"a": 1, "b": 3}
#
# # 详细容器注解
# my_list2: list[int] = [1, 2, 3]
# # print(type(my_list2))
# # for x in my_list2:
# #     print(x)
#
# my_tuple2: tuple[int, str] = (1, "a")
# # for x in my_tuple2:
# #     print(x)
#
# my_set2: set[int] = {1, 2, 3}
#
# my_dict2: dict[str, int] = {"b": 2, "a": 2}
#
#
# var_1 = random.randint(1,20) # type:int
# var_2 = json.loads('{"name":zhangsan}') #type:dict[str,str]
# def fun():
#     return 2
# var_3 = fun() # type:int
#
# # def add(num1:int,num2:int):
# #     return num1+num2
# #
# # num = add(2,2)
#
#
# def add(num1:int,num2:int)-> int:
#     return num1+num2
#
# num = add(2,2)
#
#
#
# from typing import Union
#
# my_list:list[Union[int,str]] = [1,"syr"]
# import json


# 多态
# class Animal:
#     def speak(self):
#         pass
#
# class Dog(Animal):
#     def speak(self):
#         print("汪汪汪....")
#
#
# class Cat(Animal):
#     def speak(self):
#         print("喵喵喵....")
#
#
# def make_noise(animal:Animal):
#     animal.speak()
#
#
# animal:Animal = Dog()
# make_noise(animal)
#
# animal:Animal = Cat()
# make_noise(animal)


from file_define import FileReader,TextFileReader,JsonFileReader
from data_define import  Record
from pyecharts.charts import  Bar
from pyecharts.options import  *
from pyecharts.globals import ThemeType

text_file_reader = TextFileReader("1月.txt")
json_file_reader = JsonFileReader("2月.txt")
jan_data: list[Record] = text_file_reader.Read()
feb_data: list[Record] = json_file_reader.Read()

# 将两个数据合并
all_data = jan_data+feb_data


# # 进行数据计算
# data_dict = dict()
#
# for data in all_data:
#     if data.date in data_dict.keys():
#         # 累加记录
#         data_dict[data.date] += data.money
#     else:
#         data_dict[data.date] = data.money
#
# # print(data_dict)
#
# # 可视化图表开发
# bar = Bar(init_opts=InitOpts(theme=ThemeType.LIGHT))
# bar.add_xaxis(list(data_dict.keys()))
# bar.add_yaxis("销售额",list(data_dict.values()),label_opts=LabelOpts(is_show=False))
# bar.set_global_opts(
#     title_opts=TitleOpts(title="每日销售额")
# )
#
# bar.render("每日销售额柱状图.html")

list_adder = []
list_money = []
for data in all_data:
    list_money.append(data.money)
    list_adder.append(data.province)

# 可视化图表开发
bar = Bar(init_opts=InitOpts(theme=ThemeType.LIGHT))
bar.add_xaxis(list_adder)
bar.add_yaxis("销售额",list_money,label_opts=LabelOpts(is_show=False))
bar.set_global_opts(
    title_opts=TitleOpts(title="每日销售额")
)
# 生成图表
bar.render("每城销售额.html")