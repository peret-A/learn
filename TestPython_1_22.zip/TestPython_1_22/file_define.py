# 导包
import json

from data_define import Record


#  对文件的处理
class FileReader:
    def Read(self):
        pass


class TextFileReader(FileReader):
    def __init__(self, path):
        self.path = path

    # 对父类进行复写
    def Read(self) -> list[Record]:
        # 打开文件
        f = open(self.path, 'r', encoding='utf-8')
        # 将数据按行输出
        lines = f.readlines()

        # 关闭文件
        f.close()
        # 定义一个list用于返回
        record_list = []
        for line in lines:
            # 先去掉每行的 \n  和首尾空格
            line = line.strip()

            # 按 ， 分隔  分隔后数据变成list类型的
            line_list = line.split(",")
            # line_list[2]是str类型的 要变成 int
            record = Record(line_list[0], line_list[1], int(line_list[2]), line_list[3])
            record_list.append(record)

        return record_list


class JsonFileReader(FileReader):
    def __init__(self, path):
        self.path = path

        # 对父类进行复写

    def Read(self) -> list[Record]:
        # 打开文件
        f = open(self.path, 'r', encoding='utf-8')
        # 将数据按行输出
        lines = f.readlines()
        # 关闭文件
        f.close()
        # 定义一个record_list 做返回值
        record_list = []
        for line in lines:
            data_dict = json.loads(line)
            record = Record(data_dict["date"], data_dict["order_id"],int(data_dict["money"]),data_dict["province"])
            record_list.append(record)

        return record_list


if __name__ == '__main__':
    text_file_reader = TextFileReader("1月.txt")
    record_list = text_file_reader.Read()
    for record in record_list:
        print(record)

    json_file_reader = JsonFileReader("2月.t xt")
    record_list = json_file_reader.Read()
    for record in record_list:
        print(record)


