# 导包
import json

from DataDispose import Record


# 文件处理
# FileReader抽象类
class FileReader:
    def __init__(self, path):
        self.path = path

    # 创建抽象方法reader
    def Reader(self):
        pass


# TextFileReader类继承FileReader
class TextFileReader(FileReader):
    def Reader(self) -> list[Record]:
        # 打开文件
        f = open(self.path, 'r', encoding='utf-8')

        # 将数据存储在lines里面
        lines = f.readlines()
        # 关闭文件
        f.close()
        # 创建list数据存储Record
        data_list = []

        # 将数据逐条取出放到Record
        for line in lines:
            # 去掉首尾空格和换行
            line = line.strip()
            # 以逗号分割
            line = line.split(",")
            # 创建Record
            record = Record(line[0], line[1], int(line[2]), line[3])
            # 插入数据
            data_list.append(record)
        # 返回list数据
        return data_list


# 创建JsonFileReader类继承FileReader
class JsonFileReader(FileReader):
    # 重写方法
    def Reader(self):
        # 打开文件
        f = open(self.path, 'r', encoding='utf-8')
        # 读取数据
        lines = f.readlines()
        # 关闭文件
        f.close()

        # 创建list存储Reocrd
        data_list = []

        # 插入Record数据
        for line in lines:
            # 将json数据转换成字典数据
            data_dict = json.loads(line)
            # 创建Record
            record = Record(data_dict["date"], data_dict["order_id"], int(data_dict["money"]), data_dict["province"])
            data_list.append(record)
        # 返回数据
        return data_list


if __name__ == '__main__':
    # 进行测试
    textFileReader = TextFileReader("1月.txt")
    rocord_list = textFileReader.Reader()
    for rocord in rocord_list:
        print(rocord)

    jsonFileReader = JsonFileReader("2月.txt")
    rocord_list = jsonFileReader.Reader()
    for rocord in rocord_list:
        print(rocord)
