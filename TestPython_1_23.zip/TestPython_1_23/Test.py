# # 导包
# from pymysql import Connection
# # 获取MYSQL数据库的链接对象
# conn = Connection(
#     host='localhost',   # 主机号
#     port=3306,          # 端口，默认3306
#     user = 'root',      # 用户名
#     password='123456'   # 密码
# )
#
# # 打印MYSQL数据库软件信息
# # 注：如果执行下一条语句不报错就证明你的mysql安装成功
# # print(conn.get_server_info())
#
# # 创建非查询性质的sql语句
# # 获取游标对象
# # cursor = conn.cursor()
# # conn.select_db("myss")   #选择数据库
# #使用游标对象，执行sql
# # cursor.execute("create table test_pymysql(id int,info varchar(255))")
# # 创建查询性质的sql语句
# # 获取游标对象
# cursor = conn.cursor()
# conn.select_db("myss")   #选择数据库
# #使用游标对象，执行sql
# cursor.execute("select * from sstuednt")
# results = cursor.fetchall()
# for result in results:
#     print(result)
#
# # 插入数据
# # 获取游标对象
# cursor = conn.cursor()
# conn.select_db("myss")   #选择数据库
# #使用游标对象，执行sql
# cursor.execute("insert into sstuednt values(1009,'张三',30,'女',35)")
# # 注：插入语句需要手动确认不然无法插入到数据库里
# # 注：该方式较麻烦也容易遗忘，所以建议使用下面一种方式
# # conn = Connection(
# #     host='localhost',   # 主机号
# #     port=3306,          # 端口，默认3306
# #     user = 'root',      # 用户名
# #     password='123456',  # 密码
# #     autocommit=True     # 设置自动提交
# # )
# conn.commit()
# # 关闭到数据库链接
# conn.close()


# 导包
from pymysql import Connection
from DataDispose import Record
from FileDispose import FileReader, TextFileReader, JsonFileReader

# 链接数据库
conn = Connection(
    host='localhost',  # 主机号
    port=3306,  # 端口号
    user='root',  # 用户名
    password='123456',  # 密码
    autocommit=True  # 设置自动提交
)

# 创建游标对象
cursor = conn.cursor()
# 选择数据库
conn.select_db("myss")
# 创建表
cursor.execute("create table if not exists  sales(order_date date,order_id varchar(255),money int,province varchar(10))")

# 取出数据
text_data_list = TextFileReader("1月.txt").Reader()
json_data_list = JsonFileReader("2月.txt").Reader()
# 合并数据
all_list = text_data_list + json_data_list

# 插入数据
for record in all_list:
    sql = (f"insert into sales(order_date,order_id,money,province) values('{record.date}'"
           f",'{record.order_id}',{record.money},'{record.province}')")
    # print(sql)
    cursor.execute(sql)

# 关闭数据库
conn.close()
