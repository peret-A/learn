package com.bdqn.demo02;

public class Demo03 {
    public static void main(String[] args) {
        /*
        * 使用do-while循环输出1000-2024年之间所有的闰年，每5个在一行显示
        *   闰年：满足下面条件中的一个，就是闰年
        *       1）能被4整除但是不能被100整除
        *       2）能被400整除
        * */

        //初始值
        int year = 1000;
        //声明一个变量用来统计输出的闰年个数
        int count = 0;

        do{
            //这里要输出的是闰年，所以在输出年份之前要对年份进行闰年判断
            if(year%4==0&&year%100!=0||year%400==0){
                System.out.print(year+" ");
                //输出一个闰年，统计变量+1
                count++;
                //闰年个数每加1，就对count值进行判断，能不能被5整除
                if(count%5==0){
                    //换行
                    System.out.println();
                }
            }
            year++;
        }while(year<=2024);


    }
}
