package com.bdqn.demo02;

public class Demo04 {
    public static void main(String[] args) {
        //使用while循环和do-while循环在控制台输出“*****”

        System.out.println("*****");

        System.out.println("--------------------------------");

        System.out.print("*");
        System.out.print("*");
        System.out.print("*");
        System.out.print("*");
        System.out.print("*");

        System.out.println("\n--------------------------------");

        //使用while循环输出“*****”
        int i =1;
        while(i<=5){
            System.out.print("*");
            i++;
        }

        System.out.println("\n--------------------------------");

        int j =1;
        do{
            System.out.print("*");
            j++;
        }while(j<=5);
    }
}
