package com.bdqn.demo02;

import java.util.Scanner;

public class Demo02 {

    public static void main(String[] args) {
        /*
        * 经过几天的学习，老师给张浩一道测试题，让他先上机编写程序完成，然后老师检查是否合格。如果不合格，则继续编写……
        * */

        //创建Scanner对象
        Scanner scanner = new Scanner(System.in);
        //初识值
        String answer ;
        do{
            //循环操作
            System.out.println("上机编写程序.........");
            System.out.println("编写程序是否合格(合格/不合格)：");
            //迭代
            answer =scanner.next();
        }while(answer.equals("不合格"));//循环条件

        System.out.println("继续努力....");
    }
}
