package com.bdqn.demo03;

public class Demo03 {

    public static void main(String[] args) {

        //for循环常见问题1：初始值没有声明就直接使用，程序报错
//        for(;i<10;i++){
//            System.out.println("这是 "+i);
//        }
        //解决办法：声明初始值，初始值声明可以在for循环()中声明，也可以在for循环前面声明
//        int i =1;
//        for(;i<10;i++){
//            System.out.println("这是 "+i);
//        }

//        for(int i =1;i<10;i++){
//            System.out.println("这是 "+i);
//        }

        System.out.println("----------------------------");

        //for循环常见问题1：缺少循环条件，程序进入死循环
//        for(int i=0;;i++){
//            System.out.println("这是 "+i);
//        }

        //解决办法：添加循环条件
//        for(int i=0;i<=100;i++){
//            System.out.println("这是 "+i);
//        }

        System.out.println("----------------------------");

        //for循环常见问题3：缺少迭代代码，程序进入死循环
//        for(int i=0;i<10;){
//            System.out.println("这是 "+i);
//        }

        //解决办法：添加迭代代码，可以在for循环()里添加，也可以在for循环{}中添加
//        for(int i=0;i<10;i++){
//            System.out.println("这是 "+i);
//        }

//        for(int i=0;i<10;){
//            System.out.println("这是 "+i);
//            i++;
//        }

        System.out.println("----------------------------");

        //for循环常见问题4：缺少初始值、循环条件、迭代代码，程序进入死循环，解决办法就是补充相关缺少的内容
        for(;;){
            System.out.println("这是测试");
        }


    }
}
