package com.bdqn.demo03;

import java.util.Scanner;

public class Demo02 {

    public static void main(String[] args) {
        //创建Scannner对象
        Scanner scanner =new Scanner(System.in);
        System.out.println("请输入一个整数：");
        int num = scanner.nextInt();
        System.out.println("根据这个值可以输出以下加法表：");

        for(int i =0,j=num;i<=num&&j>=0;i++,j--){
            System.out.println(i+"+"+j+"="+num);
        }

    }
}
