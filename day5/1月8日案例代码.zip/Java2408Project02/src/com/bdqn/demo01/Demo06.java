package com.bdqn.demo01;

public class Demo06 {

    public static void main(String[] args) {

        //求1-100之间所有偶数之和

        //初始值
        int i=1;
        //声明一个变量用来存储累加的数据之和
        int sum =0;

        while(i<=100){//循环条件
            //累加：在这里，不是所有i的值都累加到sum变量中，只有i的值为偶数的时候才累加，所以在累加之前要进行奇偶数判断
            if(i%2==0){
                sum+=i;
            }

            i++;//迭代
        }

        System.out.println("1-100之间所有偶数之和："+sum);
    }
}
