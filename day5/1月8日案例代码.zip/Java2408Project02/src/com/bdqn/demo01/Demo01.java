package com.bdqn.demo01;

public class Demo01 {

    //输出10遍：好好学习，天天向上
    public static void main(String[] args) {
        System.out.println("第1遍：好好学习，天天向上。");
        System.out.println("第2遍：好好学习，天天向上。");
        System.out.println("第3遍：好好学习，天天向上。");
        System.out.println("第4遍：好好学习，天天向上。");
        System.out.println("第5遍：好好学习，天天向上。");
        System.out.println("第6遍：好好学习，天天向上。");
        System.out.println("第7遍：好好学习，天天向上。");
        System.out.println("第8遍：好好学习，天天向上。");
        System.out.println("第9遍：好好学习，天天向上。");
        System.out.println("第10遍：好好学习，天天向上。");

        System.out.println("---------------------------------");

        //使用循环方式输出10000遍好好学习天天向上
        int i =1;
        while(i<=10){
            System.out.println("第"+i+"遍：好好学习，天天向上");
            i++;
        }
    }

}
