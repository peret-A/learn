package com.bdqn.demo01;

public class Demo05 {

    public static void main(String[] args) {

        //输出1-100之间所有整数之和
        //初始值
        int i =1;
        //声明一个变量sum用来累加i的值
        int sum = 0;

        while(i<=100){//循环条件
            //在这里，不再是输出i的值，而是将i的值累加，需要将累加的结果存储在一个变量中
            sum+=i;//sum=i+sum;
            i++;
        }

        System.out.println("1-100之间所有整数之和："+sum);

    }
}
