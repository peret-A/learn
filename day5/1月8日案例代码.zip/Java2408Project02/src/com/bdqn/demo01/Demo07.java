package com.bdqn.demo01;

import java.util.Scanner;

public class Demo07 {

    public static void main(String[] args) {
        /*
        * 老师每天检查张浩的学习任务是否合格，如果不合格，则继续进行。
        * 老师给张浩安排的每天的学习任务为：上午阅读教材，学习理论部分，下午上机编程，掌握代码部分*
        * */

        //创建Scanner对象
        Scanner scanner = new Scanner(System.in);

        //初始值
        System.out.println("学习任务是否合格(合格/不合格)：");
        String answer =scanner.next();

        while(answer.equals("不合格")){
            //循环操作：只要学习任务不合格，就需要执行下面的循环操作代码
            System.out.println("上午阅读教材，学习理论部分，下午上机编程，掌握代码部分");
            //迭代：检查学习任务是否合格
            System.out.println("学习任务是否合格(合格/不合格)：");
            answer =scanner.next();
        }

        System.out.println("继续努力......");

    }
}
