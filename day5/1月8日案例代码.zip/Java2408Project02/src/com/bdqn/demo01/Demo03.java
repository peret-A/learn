package com.bdqn.demo01;

public class Demo03 {

    public static void main(String[] args) {

        //使用while循环输出1-100之间所有的整数
        //初始值
        int i =1;
        while(i<=100){//循环条件
            //循环操作：输出整数
            System.out.println(i);
            //迭代
            ++i;
        }

        System.out.println("数据输出完毕");
    }
}
