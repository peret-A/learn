package com.bdqn.demo01;

public class Demo08 {

    public static void main(String[] args) {
        /*
        * 输出所有的水仙花数
        *   水仙花数：一个三位数，各个位上数字的三次方之和等于这个数本身
        *       例如：153=1^3+5^3+3^3
        *   扩展：
        *       四叶草数：一个四位数，各个位上数字的四次方之和等于这个数本身
        *
        *       十全十美数：一个十位数，各个位上数字的十次方之和等于这个数本身
        * */

        //初始值
        int i=100;
        //循环条件
        while(i<1000){
            //对i的值进行判断：各个位上数字的三次方之和等于这个数本身
            //获取i这个三位数各个位上的数字，借助/和%运算符实现
            int geWei = i%10;
            int shiWei =i/10%10;
            int baiWei=i/100;
            //将各个位上的数字进行三次方操作，然后累加到一块
            int sum =geWei*geWei*geWei+shiWei*shiWei*shiWei+baiWei*baiWei*baiWei;
            //判断累加的sum值与i的值是否相等，相等就是水仙花数
            if(sum==i){
                System.out.println(i);
            }

            //迭代
            i++;
        }


    }
}
