package com.bdqn.demo01;

public class Demo04 {

    public static void main(String[] args) {
        //输出1-100之间所有的偶数
        //初始值
        int i =1;
        while(i<=100){//循环条件
            //循环操作：输出数据，在这里，不是什么数都输出，只输出偶数，所以在输出数据之前，要对数据进行判断
            if(i%2==0){//能被2整除的数是偶数
                System.out.println(i);
            }
            i++;
        }

        System.out.println("数据输出完毕");
    }
}
