package bdqn.test03;

import java.util.*;

public class test01 {
    public static void main(String[] args) {
        // 6. 请你自编一个用户名和密码的信息，再加上验证码；（4位）
        //
        //要求：请用HashMap进行封装，用Scanner进行验证（用户名和密码
        //
        //必须是一一对应）且验证码也必须是正确，才能算“登录成功”
        //创建Scanner对象
        Scanner scanner =new Scanner(System.in);

        //准备数据
        User user1 =new User("root",123);
        User user2 =new User("admin",123);
        //准备容器
        HashMap<String,Integer> hashMap =new HashMap<>();
        hashMap.put(user1.getName(),user1.getPwd());
        hashMap.put(user2.getName(),user2.getPwd());
        //登录
        String root = scanner.next();
        int pwd = scanner.nextInt();
        Set keys = hashMap.keySet();
        boolean result =true;
        for (var key :keys){
            if(key.equals(root)&&hashMap.get(key).equals(pwd)){
                result =false;
                //准备4位验证码
                Random random =new Random();
                int captcha = random.nextInt(10000);
                //显示验证码
                System.out.println("验证码: "+captcha);
                //输入验证码
                int index =scanner.nextInt();
                if(index == captcha){
                    System.out.println("登录成功");
                }
                else{
                    System.out.println("验证码错误");
                }
                break;
            }
        }
        if(result){
            System.out.println("账号或者密码错误");
        }


    }
}
