package bdqn.test03;

import java.util.ArrayList;
import java.util.Iterator;

public class test {
    public static void main(String[] args) {
        //5.已知有两个容器（Ｌist），第一容器中有：[小明，小东，小猪]
        //
        //第二容器中有：[100分，95分，89分]；
        //
        //（１）请把第二个容器中的100分改成98分；*       8分钟
        //
        //（２）请用迭代(iterator)来做，在控制台上输出：**(双迭代)

        //准备容器
        ArrayList<String> arrayListString = new ArrayList<>();
        ArrayList<Integer> arrayListInteger = new ArrayList<>();
        arrayListString.add("小明");
        arrayListString.add("小东");
        arrayListString.add("小猪");
        arrayListInteger.add(100);
        arrayListInteger.add(95);
        arrayListInteger.add(89);
//        （１）请把第二个容器中的100分改成98分；
        int index = arrayListInteger.indexOf(100);
        arrayListInteger.set(index,98);
//        （２）请用迭代(iterator)来做，在控制台上输出：**(双迭代)
        Iterator iteratorInteger = arrayListInteger.iterator();
        while (iteratorInteger.hasNext()){
            System.out.print(iteratorInteger.next()+" ");
        }
        System.out.println();
        Iterator iteratorString = arrayListString.iterator();
        while (iteratorString.hasNext()){
            System.out.print(iteratorString.next()+" ");
        }
        System.out.println();

    }


}
