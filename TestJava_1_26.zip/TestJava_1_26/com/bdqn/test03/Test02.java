package bdqn.test03;

import java.util.*;

public class Test02 {
    public static void main(String[] args) {
        //7.已知有两个字符串数组类型：　　*
        //String[] s1={"苹果"，"***","绿色"};
        //String[] s2={"apple","yellow","green"};
        //(1)请用一个容器把这两个数组装进去，然后在控制台上输出：
        //{苹果=apple,***=yellow,绿色=green}
        //(2)把以上两个数组的元素放在一个自定义的A类中，然后再用容器把它们装起来，再输出；格式跟（1）一样
        String[] s1={"苹果","***","绿色"};
        String[] s2={"apple","yellow","green"};
        //(1)请用一个容器把这两个数组装进去，然后在控制台上输出：
        //准备容器
        HashMap<String,String> hashMap =new HashMap<>();
        for (int i = 0; i < s1.length; i++) {
            hashMap.put(s1[i],s2[i]);
        }
        //遍历
        System.out.println(hashMap);


    }
}
