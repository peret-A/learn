package bdqn.test02;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class Test {
    //2.int[][] a={{1,2,3},{6,5},{4,10,15}};
    //
    //    请用Collections,ArrayList,进行排序（从大到小）
    //
    //   依次输出（遍历）；
    public static void main(String[] args) {
        int[][] a={{1,2,3},{6,5},{4,10,15}};
        // 请用Collections,ArrayList,进行排序（从大到小）
        //准备容器
        ArrayList<Integer>  arrayList =new ArrayList<>();
        //插入数据
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                arrayList.add(a[i][j]);
            }
        }
        //排序(大到小)
        //该排序是小到大
        Collections.sort(arrayList);
        //反转
        Collections.reverse(arrayList);

        //遍历
        Iterator iterator = arrayList.iterator();
        while (iterator.hasNext()){
            System.out.print(iterator.next()+" ");
        }
    }
}
