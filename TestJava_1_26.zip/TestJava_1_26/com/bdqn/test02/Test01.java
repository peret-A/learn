package bdqn.test02;

import java.util.ArrayList;
import java.util.Scanner;

public class Test01 {
    public static void main(String[] args) {
        //3.请用一个容器把如下用户名：hot,rainbow,hyx,xiaohuang装起来；
        //
        //再用一个容器把用户名对应的密码：123，123４，1234５，159357也装起来；
        //
        //要求：
        //
        //请用Scanner输入用户和密码，进行判断；如果输入的用户名和密码是上面所有的，
        //
        //就输出“判断成功”，否则继续输入，名直到正确为止；


        //准备数据
        User user1 =new User("hot",123);
        User user2 =new User("rainbow",1234);
        User user3 =new User("hyx",12345);
        User user4 =new User("xiaohuang",159357);

        //准备容器
        ArrayList<User> arrayListUser =new ArrayList<>();
        //int是无法存储在集合中
        //插入数据
        arrayListUser.add(user1);
        arrayListUser.add(user2);
        arrayListUser.add(user3);
        arrayListUser.add(user4);


//        请用Scanner输入用户和密码，进行判断；如果输入的用户名和密码是上面所有的，
        //创建Scanner对象
        Scanner scanner =new Scanner(System.in);
        String user_name=scanner.next();
        String user_pwd =scanner.next();
//        进行判断
        int i;
        for (i = 0; i < arrayListUser.size(); i++) {
            if(arrayListUser.get(i).getUser().equals(user_name)&&arrayListUser.get(i).getPwd()==Integer.parseInt(user_pwd)){
                System.out.println("判断成功");
                break;
            }
        }
        if (i == arrayListUser.size()){
            System.out.println("错误");
        }
    }

}
