package bdqn.test02;

public class User {
    private String user;
    private int pwd;

    @Override
    public String toString() {
        return "User{" +
                "user='" + user + '\'' +
                ", pwd=" + pwd +
                '}';
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public int getPwd() {
        return pwd;
    }

    public void setPwd(int pwd) {
        this.pwd = pwd;
    }

    public User() {
    }

    public User(String user, int pwd) {
        this.user = user;
        this.pwd = pwd;
    }
}
