package bdqn.test01;

import java.util.*;

public class StudentTest {
    public static void main(String[] args) {
//        Student student1 =new Student();
//        student1.setName("小明");
//        student1.setGender(Gender.女);
//
//        Student student2 =new Student();
//        student2.setName("小明");
//        student2.setGender(Gender.男);
//
//        Student student3 =new Student();
//        student3.setName("小明");
//        studen3.setGender(Gender.你好);


//        Student student1 =new Student();
//        student1.name ="小明";
//        student1.gender = Gender.女;
//
//        Student student2 =new Student();
//        student2.name ="小红";
//        student2.gender = Gender.男;
//
//        Student student3 =new Student();
//        student3.name ="小黑";
//        student3.gender =Gender.你好;

//        //装箱与拆箱
//        int num1 =100;
//        Integer integer1 = num1;
//        System.out.println(num1);
//        System.out.println(integer1);
//
//        Byte byte1 = Byte.valueOf("123");
//
//        byte num2 =byte1;
//        System.out.println(byte1);
//        System.out.println(num2);

//        int num = (int) (Math.random()*20+20);
//        System.out.println(Integer.MAX_VALUE);
//        System.out.println(Integer.MAX_VALUE);
//        float f  = Float.parseFloat("12.5f");
//    String str1 = Integer.toString(123);
//    String str2 = Character.toString('w');
//        System.out.println(str1 + str2);

//
//        Random random =new Random();
//        boolean bool;
//        for (int i = 0; i < 10; i++) {
//            bool = random.nextBoolean();
//            System.out.print(bool+"  " );
//        }
//        System.out.println("-------------");
//
//        int num1;
//        for (int i = 0; i < 10; i++) {
//            num1 = random.nextInt();
//            System.out.print(num1+"  ");
//        }
//        System.out.println("-------------");
//
//        int num2 ;
//        for (int i = 0; i < 10; i++) {
//            num2 = random.nextInt(100);
//            System.out.print(num2+"  " );
//        }
//        System.out.println("-------------");
//
//        double dou = random.nextGaussian();
//        System.out.println(dou );
//        //创建String对象
//        String s1 = new String();
//        System.out.println(s1);
//
//        //String(byte[] bytes, Charset charset)
//        //通过使用指定的 charset 解码指定的 byte 数组，构造一个新的 String。
//        byte[] bytes ={97,98,99};
//        String s2 =new String(bytes);
//        System.out.println(s2);
//        //String(byte[] bytes, int offset, int length)
//        //offset 是起始下标 length是截取长度
//        //通过使用平台的默认字符集解码指定的 byte 子数组，构造一个新的 String。
//        byte[] bytes2 ={97,98,99,100,101,102,103};
//        String s3 =new String(bytes2,1,4);
//        System.out.println(s3);
//        //String(char[] value)
//        //分配一个新的 String，使其表示字符数组参数中当前包含的字符序列。
//        char[] name ={'奥','特','曼','大','站','小','老','板'};
//        String s4 =new String(name);
//        System.out.println(s4);
//        //String(char[] value, int offset, int count)
//        //分配一个新的 String，它包含取自字符数组参数一个子数组的字符。
//        String s5 =new String(name,0,3);
//        System.out.println(s5);


//        String s1 ="hello";
//        String s2 =" world";
//        String s3 =s1+s2;
//        System.out.println(s3);
//
//        String s4 = s1.concat(s2);
//        System.out.println(s4);
//
//        for (int i = 0; i < s4.length(); i++) {
//            System.out.print(s4.charAt(i)+" ");
//        }
//        System.out.println();
//
//        //int indexOf(int ch)  返回指定字符在此字符串中第一次出现处的索引，如果找不到就返回-1
////        注： int ch 是指char类型对应的ASCII的数值
//        System.out.println(s4.indexOf('i'));
//        System.out.println(s4.indexOf(119));
////        int indexOf(int ch, int fromIndex) 返回在此字符串中第一次出现指定字符处的索引，从指定的索引开始搜索。如果找不到就返回-1
////        注：fromIndex 是起始下标
////
////        int indexOf(String str) 返回指定子字符串在此字符串中第一次出现处的索引。如果找不到就返回-1
////        int indexOf(String str, int fromIndex) 返回指定子字符串在此字符串中第一次出现处的索引，从指定的索引开始。如果找不到就返回-1
////        注：fromIndex 是起始下标
//
//        System.out.println(s4.indexOf("he"));
//        System.out.println(s4.indexOf("he",3));

//1. 输入5个数，装入容器中ArrayList，将数从小到大输出，从大到小输出，随机输出
       //准备容器
        ArrayList<Integer> arrayList =new ArrayList<>();

        //插入数据
        arrayList.add(1);
        arrayList.add(3);
        arrayList.add(2);
        arrayList.add(9);
        arrayList.add(8);

        //将数组排序
        Collections.sort(arrayList);
        Iterator<Integer> iterator =arrayList.iterator();
        //遍历
        while (iterator.hasNext()){
            System.out.print(iterator.next()+" ");
        }
        System.out.println();
        //从大到小输出

        Collections.reverse(arrayList);
        //遍历
        iterator =arrayList.iterator();
        while (iterator.hasNext()){
            System.out.print(iterator.next()+" ");
        }
        System.out.println();
//      随机输出
        //设置随机数 [0 arraylist.size()-1)
        Random random=new Random();
        int index ;
        while (!arrayList.isEmpty()){
            index =random.nextInt(arrayList.size());
            System.out.print(arrayList.get(index)+" ");
            arrayList.remove(index);
        }
    }

}
