package bdqn.test01;

public enum Gender {
    男,女
}
