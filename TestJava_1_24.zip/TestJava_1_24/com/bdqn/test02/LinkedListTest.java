package bdqn.test02;

import java.util.Iterator;
import java.util.LinkedList;

public class LinkedListTest {
    /***
     * 常用方法：
     * void add(Object o)  尾加
     * void addFirst(Object o)  首插
     * void addLast(Object o) 尾加
     * void add(int , Object o) 在指定位置插入指定对象
     *
     * Object remove(int) 删除指定下标的对象
     * boolean remove(Object o) 删除第一次遇到这个对象并返回true，如果一直没有找到返回false
     * Object removeFirst() 首删
     * Object removeLast() 尾删
     * boolean removeFirstOccurrence(Object)  在循环遍历中删除第一次遇到这个对象
     * boolean removeLastOccurrence(Object)  在循环遍历中删除最后一次遇到这个对象
     *
     * int indexOf(Object o) 返回对象的下标
     * int lastIndexOf(Object o) 返回最后一次遇到这个对象的下标    ·
     * @param args
     */
    public static void main(String[] args) {
        //准备容器
        LinkedList linkedList =new LinkedList<>();

        // 准备数据
        Student student =new Student("小明",15);
        Student student1 = new Student("小红",16);
        Student student2 = new Student("小何",17);
        Student student3 = new Student("小黑",18);
        Student student4 = new Student("晓晓",19);

        //插入数据
        linkedList.add(student2);
        linkedList.add(student1);
        linkedList.add(student4);
        linkedList.add(1,student3);
        linkedList.addFirst(student2);
        linkedList.addLast(student4);
        linkedList.add(2,student4);
        linkedList.addLast(student2);

        //遍历
        for (Object obj :linkedList){
            System.out.println(obj);
        }
        System.out.println("------------------------------------");
        //查询数据
        System.out.println(student1+":"+linkedList.indexOf(student1));
        System.out.println(student2+":"+linkedList.indexOf(student2));
        System.out.println(student3+":"+linkedList.lastIndexOf(student3));
        System.out.println(student4+":"+linkedList.lastIndexOf(student4));

        System.out.println("------------------------------------------------");
        //删除数据
        linkedList.remove(student1);
        linkedList.remove(student4);
        linkedList.remove(3);
        linkedList.removeFirst();
        linkedList.removeLast();
        linkedList.removeLastOccurrence(student3);
        linkedList.removeFirstOccurrence(student1);

        //遍历
        Iterator iterator = linkedList.iterator();
        while (iterator.hasNext()){
            System.out.println(iterator.next());
        }

        System.out.println(linkedList.size());
        linkedList.clear();
        System.out.println(linkedList.isEmpty());
        System.out.println("--------------------------------------");
        linkedList.push(student1);
        linkedList.push(student2);
        linkedList.push(student3);
        linkedList.push(student4);
        linkedList.push(student);
        linkedList.pop();
        iterator = linkedList.iterator();
        while (iterator.hasNext()){
            System.out.println(iterator.next());
        }
        System.out.println("-----------------------------------------");
        System.out.println(linkedList.peek());
        System.out.println(linkedList.peekLast());
        System.out.println(linkedList.offerFirst(student2));
        iterator = linkedList.iterator();
        while (iterator.hasNext()){
            System.out.println(iterator.next());
        }
        System.out.println(linkedList.poll());
    }
}
