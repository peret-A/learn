package bdqn.test02;



import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListTest {
    /***
     * 常用方法有
     * void add（Object o） 尾加
     * void add(int index, Object o)  在指定位置插入指定对象
     * Object remove(int index) 取出指定下标的对象
     * boolean remove(Object o) 判断对象是否在集合中，如果在取出遇到的第一个对象 再返回true 否则返回false
     * int indexOf(Objecct o ) 根据对象返回下标
     * int lastIndexOf(Object )  查询最后一次出现的下标
     * int size()   返回集合长度
     * void clear()  将集合清空
     * boolean isEmpty()  判断集合是否为空
     * boolean contain(Object o)  皮肤对象是否存在
     * Object get(int)   根据下表返回对象
     * String toString(ArrayList) 将集合变成字符串类型
     * 特点： 有序  数组型 查询效率高  删除插入效率较低
     * @param args
     */


    public static void main(String[] args) {
        // 准备容器
        ArrayList arrayList =new ArrayList();

        // 准备数据
        Student student =new Student("小明",15);
        Student student1 = new Student("小红",16);
        Student student2 = new Student("小何",17);
        Student student3 = new Student("小黑",18);
        Student student4 = new Student("晓晓",19);

        //插入数据
        arrayList.add(student);
        arrayList.add(student1);
        arrayList.add(2,student3);
        arrayList.add(student3);
        arrayList.add(student4);
        arrayList.addFirst(student3);
        arrayList.add(3,student1);
        arrayList.addLast(student2);
        arrayList.add(student4);

        //遍历
        for (Object obj : arrayList){
            System.out.println(obj);

        }

        System.out.println("---------------------------------------------");
        //删除元素
        arrayList.remove(2);
        arrayList.remove(student2);
        arrayList.removeFirst();
        arrayList.removeLast();
        // 遍历
        Iterator iterator =arrayList.iterator();
        while (iterator.hasNext()){
            System.out.println(iterator.next());
        }
        System.out.println("-----------------------------------------------");
        //查找元素
        System.out.println(student2+"在："+arrayList.indexOf(student2));
        System.out.println(student3+"在："+arrayList.indexOf(student3));
        System.out.println(student+"在："+arrayList.contains(student));
        System.out.println("数组长度: "+arrayList.size());
        arrayList.clear();
        System.out.println("数组长度: "+arrayList.size());

        System.out.println("数组空: "+arrayList.isEmpty());
    }
}
