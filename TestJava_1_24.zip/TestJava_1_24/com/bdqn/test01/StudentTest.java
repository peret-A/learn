package bdqn.test01;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;

public class StudentTest {
    public static void main(String[] args) {
//        Student student =new Student("小明",22);
//        Student student1 =new Student("小红",22);
//        Student student2 =new Student("小何",22);
//
//        ArrayList arrayList = new ArrayList();
//        // 添加元素 add
//        arrayList.add(student);
//        arrayList.add(student1);
//        arrayList.add(student2);

//        //查看list个数
//        int size = arrayList.size();
//        System.out.println("元素个数: "+size);
//
//        //获取集合的第一个元素
//        Object object1 = arrayList.get(0);
//        System.out.println(object1);
//        //将Object转换成实现类Student
//        Student student3 =(Student) object1;
//        System.out.println(student3);
//
//        //遍历list
//        for(var x: arrayList){
//            System.out.println(x);
//        }
//        Iterator iterator = arrayList.iterator();
//        while (iterator.hasNext()){
//
//            System.out.println(iterator.next());
//        }

//        ArrayList arrayList1 =new ArrayList<>();
//        arrayList.addAll((Collection) iterator);
//        iterator = arrayList1.iterator();
//                while (iterator.hasNext()){
//
//            System.out.println(iterator.next());
//        }



//        Student student =new Student("小明",22);
//        Student student1 =new Student("小红",22);
//        Student student2 =new Student("小何",22);
//
//        ArrayList arrayList = new ArrayList(0);
//        // 添加元素 add
//        arrayList.add(student);
//        arrayList.add(student1);
//        arrayList.add(student2);
//        Object[] objects =arrayList.toArray();
//        for (var x:objects){
//            System.out.println(x);
//        }
//        Object o =arrayList.remove(student2);
//        System.out.println(o);
//        int result = arrayList.indexOf(student2);
//        System.out.println(result);
//
//        arrayList.clear();
//        System.out.println(arrayList.isEmpty());



        //准备数据
        Student student =new Student("小明",22);
        Student student1 =new Student("小红",22);
        Student student2 =new Student("小何",22);
        Student student3 =new Student("小黑",22);
        Student student4 =new Student("小文",22);
        Student student5 =new Student("奥特曼",22);

        //准备容器
        LinkedList linkedList =new LinkedList();
        //添加元素
        linkedList.add(student);
        linkedList.addLast(student2);
        linkedList.addFirst(student1);
        linkedList.add(student3);
        linkedList.add(student4);
        linkedList.add(student);
        linkedList.add(student5);
        linkedList.add(student);
        linkedList.add(student3);

        //遍历
        Iterator iterator = linkedList.iterator();
        while (iterator.hasNext()){
            System.out.println(iterator.next());
        }
        System.out.println("--------------------------------");
        //删除首尾与3号元素
        linkedList.removeFirst();
        linkedList.removeLast();
        linkedList.remove(3);

        iterator = linkedList.iterator();
        while (iterator.hasNext()){
            System.out.println(iterator.next());
        }

        System.out.println("--------------------------------");
        //删除最后一次的小明 删除第一次的小明
        boolean result = linkedList.removeLastOccurrence(student);
        linkedList.removeFirstOccurrence(student);
//        System.out.println(result);
        iterator = linkedList.iterator();
        while (iterator.hasNext()){
            System.out.println(iterator.next());
        }
        System.out.println("--------------------------------");
        //清空
        linkedList.clear();
        //判断空
        result = linkedList.isEmpty();
        System.out.println(result);


    }

}
