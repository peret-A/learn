package bdqn.test02;

public class InterEms implements Ems{

    @Override
    public String getType() {
        return "CD";
    }

    @Override
    public String getCapacity() {
        return "4GB";
    }
}
