package bdqn.test02;

public interface Cpu {
    public abstract  String getBrand();
    public abstract String  getFrequency();
}
