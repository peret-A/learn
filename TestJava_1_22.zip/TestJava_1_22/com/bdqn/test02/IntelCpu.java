package bdqn.test02;

public class IntelCpu implements Cpu{
    @Override
    public String getBrand() {
        return "Intel";
    }

    @Override
    public String getFrequency() {
        return "3.8GHz";
    }
}
