package bdqn.test02;

public class SolidStateDrives implements HardDisk{
    @Override
    public String getCapacity() {
        return "300GB";
    }
}
