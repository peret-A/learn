package bdqn.test02;

public interface Ems {
    public abstract String getType();
    public abstract String getCapacity();
}
