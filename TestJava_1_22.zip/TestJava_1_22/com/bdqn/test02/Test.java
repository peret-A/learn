package bdqn.test02;

public class Test {
    public static void main(String[] args) {
        //创建CPu Ems HardDisk 因为他们都是接口无法直接实例化 只能通过实现类去实例化
        Cpu cpu =new IntelCpu();
        Ems ems=new InterEms();
        HardDisk hardDisk=new SolidStateDrives();
        //创建电脑去组装
        Computer computer=new Computer();
        computer.info(cpu,ems,hardDisk);
    }

}
