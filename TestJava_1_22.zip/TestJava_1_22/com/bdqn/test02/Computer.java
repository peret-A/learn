package bdqn.test02;

public class Computer {
    public void info(Cpu cpu,Ems ems,HardDisk hardDisk){
        System.out.println("计算机的信息如下:");
        System.out.println("Cpu的品牌是：" + cpu.getBrand() + ",主频是：" + cpu.getFrequency());
        System.out.println("硬盘容量是：" + hardDisk.getCapacity());
        System.out.println("内存容量是：" + ems.getCapacity());
    }
}
