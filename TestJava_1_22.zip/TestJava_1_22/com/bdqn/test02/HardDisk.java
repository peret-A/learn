package bdqn.test02;

public interface HardDisk {
    String getCapacity();
}
