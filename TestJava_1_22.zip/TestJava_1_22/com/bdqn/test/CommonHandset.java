package bdqn.test;

public class CommonHandset extends Handset implements PlayWiring{

    public CommonHandset() {
    }

    public CommonHandset(String brand, String type) {
        super(brand, type);
    }

    @Override
    public void sendInfo() {
        System.out.println("这是一款型号为" + this.getType() + "的" + this.getBrand() + "手机");
    }

    @Override
    public void call() {
        System.out.println("开始语言通话...");
    }

    @Override
    public void info() {
        System.out.println("发送文字信息....");
    }

    @Override
    public void play(String in_content) {
        System.out.println("开始播放音乐《"+in_content+"》....");
    }
}
