package bdqn.test;

public class AptitudenHandset extends Handset implements PlayWiring,NetWork,TheakePictures{
    @Override
    public void sendInfo() {
        System.out.println("这是一款型号为" + this.getType() + "的" + this.getBrand() + "手机");
    }


    @Override
    public void call() {
        System.out.println("开始视频通话....");
    }

    @Override
    public void info() {
        System.out.println("发送带图片与文字的信息.....");
    }

    @Override
    public void netWorkConn() {
        System.out.println("已经启动移动网络....");
    }

    @Override
    public void play(String in_content) {
        System.out.println("开始播放视频《"+in_content+"》....");
    }

    public AptitudenHandset(String brand, String type) {
        super(brand, type);
    }

    public AptitudenHandset() {
    }

    @Override
    public void takePictures() {
        System.out.println("咔嚓.....拍照成功");
    }
}
