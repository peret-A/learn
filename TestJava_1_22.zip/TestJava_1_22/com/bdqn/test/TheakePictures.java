package bdqn.test;

public interface TheakePictures {
     default void takePictures(){};
}
