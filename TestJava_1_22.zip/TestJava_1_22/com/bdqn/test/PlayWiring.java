package bdqn.test;

public interface PlayWiring {
    default void play(String in_content){};
}
