package bdqn.test;

public interface NetWork {
    default void netWorkConn() {

    }
}

