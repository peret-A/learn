package bdqn.test;

public class Test {
    //创建普通用户进行测试
    public static void main(String[] args) {
        CommonHandset commonHandset=new CommonHandset("索尼立信","G502c");
        commonHandset.sendInfo();
        commonHandset.play("热雪");
        commonHandset.call();
        commonHandset.info();

        AptitudenHandset aptitudenHandset=new AptitudenHandset("I9100","HTC");
        aptitudenHandset.sendInfo();
        aptitudenHandset.netWorkConn();
        aptitudenHandset.play("小时代");
        aptitudenHandset.takePictures();
        aptitudenHandset.call();
        aptitudenHandset.info();
    }
}
