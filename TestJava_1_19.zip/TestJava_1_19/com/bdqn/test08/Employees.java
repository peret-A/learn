package bdqn.test08;

public class Employees extends Employee{
    @Override
    public void print() {
        System.out.println(" 普通员工工资=单日工资*天数*等级（1.0）；");
        System.out.println("工资: " + this.getWages() * this.getDay() * 1.0);
    }

    public Employees(String name, double wages, int day) {
        super(name, wages, day);
    }

    public Employees() {
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
