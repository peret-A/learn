package bdqn.test08;

public class Manager extends Employee {
    //部门经理工资=1000+单日工资*天数*等级（1.2）。

    public Manager(String name, double wages, int day) {
        super(name, wages, day);
    }

    public Manager() {
    }

    @Override
    public void print() {
        System.out.println("部门经理工资=1000+单日工资*天数*等级（1.2）。");
        System.out.println("工资: " + 1000 + this.getWages() * this.getDay() * 1.2);

    }

    @Override
    public String toString() {
        return super.toString();
    }
}
