package bdqn.test08;

public class Test {
    public static void main(String[] args) {
        Employee employee=new Manager("小明",2000,30);
        employee.print();
        System.out.println(employee.toString());
        employee=new Employees("小红",200,30);
        employee.print();
        System.out.println(employee.toString());
    }
}
