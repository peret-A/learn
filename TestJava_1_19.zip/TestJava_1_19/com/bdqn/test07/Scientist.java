package bdqn.test07;

public class Scientist extends Employee{
    /*
    （3）科学家除基本工资外,还有年终奖。
     */
    private double yearBonus;

    public double getYearBonus() {
        return yearBonus;
    }

    public void setYearBonus(double yearBonus) {
        this.yearBonus = yearBonus;
    }

    public Scientist(double wages, double yearBonus) {
        super(wages);
        this.yearBonus = yearBonus;
    }

    public Scientist() {
    }

    @Override
    public String toString() {
        return "科学家的基本工资: "+this.getWages()+"年终奖: "+this.yearBonus;
    }
}
