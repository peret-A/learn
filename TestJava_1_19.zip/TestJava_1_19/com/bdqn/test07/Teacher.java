package bdqn.test07;

public class Teacher extends Employee{

    /*
    （2）教师除基本工资外,还有课酬(元/天)。
     */
    private double remuneration;

    public double getRemuneration() {
        return remuneration;
    }

    public void setRemuneration(double remuneration) {
        this.remuneration = remuneration;
    }

    public Teacher(double wages, double remuneration) {
        super(wages);
        this.remuneration = remuneration;
    }

    public Teacher() {
    }

    @Override
    public String toString() {
        return "教师的基本工资: "+this.getWages()+"课酬(元/天): "+this.getRemuneration();
    }
}
