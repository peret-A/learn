package bdqn.test07;

public class Farmer extends Employee{
    public Farmer(double wages) {
        super(wages);
    }

    public Farmer() {
    }

    @Override
    public String toString() {
        return "农民的基本工资: "+this.getWages();
    }
}
