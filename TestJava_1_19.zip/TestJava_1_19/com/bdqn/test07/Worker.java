package bdqn.test07;

public class Worker extends Employee{
    /*
    （1）其中工人,农民,服务生只有基本工资。
     */

    public Worker(double wages) {
        super(wages);
    }

    public Worker() {
    }

    @Override
    public String toString() {
        return "工人的基本工资: "+this.getWages();
    }
}
