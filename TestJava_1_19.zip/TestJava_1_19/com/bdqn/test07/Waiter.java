package bdqn.test07;

public class Waiter extends Employee{
    public Waiter(double wages) {
        super(wages);
    }

    public Waiter() {
    }

    @Override
    public String toString() {
        return "服务员的基本工资: "+this.getWages();
    }
}
