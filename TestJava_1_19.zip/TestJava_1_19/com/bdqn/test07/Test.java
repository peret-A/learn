package bdqn.test07;

public class Test {
    public static void main(String[] args) {
        Employee employee=new Worker(2000);
        System.out.println(employee.toString());
        employee=new Farmer(2000);
        System.out.println(employee.toString());
        employee=new Waiter(2000);
        System.out.println(employee.toString());
        employee=new Teacher(2000,20);
        System.out.println(employee.toString());
        employee=new Scientist(2000,20);
        System.out.println(employee.toString());
    }
}
