package bdqn.test05;

public class Point {
    /*
    21:定义平面内点的类Point，属性有横坐标和纵坐标。
    （1）每个属性都使用private修饰，为每个属性设置setter和getter方法。
    （2）设置无参的构造方法
    （3）设置有参的构造方法Point（int x，int y）
    （4）设置有参的构造方法Point（Point p）
    （5）重写toString()方法，用于输出坐标点的信息
    （6）重写euqals()方法，用于对两个坐标点进行比较
     */
    private double pointX;
    private double pointY;

    public double getPointX() {
        return pointX;
    }

    public void setPointX(double pointX) {
        this.pointX = pointX;
    }

    public double getPointY() {
        return pointY;
    }

    public void setPointY(double pointY) {
        this.pointY = pointY;
    }

    public Point() {
    }

    public Point(double pointX, double pointY) {
        this.pointX = pointX;
        this.pointY = pointY;
    }

    public Point(Point point) {
        this.pointX = point.pointX;
        this.pointY = point.pointY;
    }

    //（5）重写toString()方法，用于输出坐标点的信息
    public String toString(){
        return "("+pointX+","+pointY+")";
    }

    //（6）重写euqals()方法，用于对两个坐标点进行比较
    public boolean equals(Object object){
        if(this == object){
            return true;
        }
        if(object instanceof Point point){
            return this.getPointX()==point.getPointX()&&this.getPointY()==point.getPointY();
        }
        return false;
    }
}
