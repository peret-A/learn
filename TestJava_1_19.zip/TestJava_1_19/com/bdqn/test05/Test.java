package bdqn.test05;

public class Test {
    public static void main(String[] args) {
        Point point1 =new Point(2,2);
        Point point2 =new Point(point1);
        Point point3 = new Point(2,2);
        System.out.println("第一点: "+point1);
        System.out.println("第二点: "+point2);
        System.out.println("第三点: "+point3);
        System.out.println("第一点与第二点相同: "+point1.equals(point2));
        System.out.println("第一点与第三点相同: "+point1.equals(point3));
    }
}
