package bdqn.test06;

public class Circle extends Picture{
    // 圆形类：包含圆心和半径，重写求周长和求面积的方法。
    private String center;
    private double radius;
    //重写求周长和求面积的方法

    @Override
    public double circumference() {

        return radius*2*Math.PI;
    }

    public String getCenter() {
        return center;
    }

    public void setCenter(String center) {
        this.center = center;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public Circle(String center, double radius) {
        this.center = center;
        this.radius = radius;
    }

    public Circle() {
    }

    @Override
    public double area() {
        return Math.PI*radius*radius;
    }

    @Override
    public String toString() {
        return "圆点是： "+this.getCenter()+"，半径: "+this.getRadius();
    }
}
