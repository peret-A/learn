package bdqn.test06;

public class Test {
    public static void main(String[] args) {
        Circle circle=new Circle("(0,0)",2);
        System.out.println("圆点的周长: "+circle.getCenter());
        System.out.println("圆的面积: "+circle.area());
        System.out.println(circle.toString());
        Rect rect=new Rect(3,4);
        System.out.println("长方形的周长: "+rect.circumference());
        System.out.println("长方形的面积: "+rect.area());
        System.out.println(rect.toString());

    }
}
