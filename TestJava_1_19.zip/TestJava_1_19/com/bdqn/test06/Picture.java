package bdqn.test06;

public class Picture {
    /*
    18：定义一个图形类Picture，再定义Picture的两个子类：圆形类Circle、矩形类Rect。
   要求：
    图像类：有求周长和求面积和显示图形信息的功能。
    圆形类：包含圆心和半径，重写求周长和求面积的方法。
    矩形类：包含长和宽，重写求周长和求面积的方法。
     */
    public double circumference(){
        return 0.0;
    }
    public double area(){
        return 0.0;
    }

    //显示图形信息的功能。
    public String toString(){
        return "";
    }

}
