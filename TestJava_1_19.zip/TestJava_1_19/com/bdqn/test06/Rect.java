package bdqn.test06;

public class Rect extends Picture{
    /*
    矩形类：包含长和宽，重写求周长和求面积的方法。
     */
    private double lenght;
    private double wight;

    public double getLenght() {
        return lenght;
    }

    public void setLenght(double lenght) {
        this.lenght = lenght;
    }

    public double getWight() {
        return wight;
    }

    public void setWight(double wight) {
        this.wight = wight;
    }

    public Rect() {
    }

    public Rect(double lenght, double wight) {
        this.lenght = lenght;
        this.wight = wight;
    }



    //重写求周长和求面积的方法。

    @Override
    public double circumference() {
        return lenght*2+wight*2;
    }

    @Override
    public double area() {
        return lenght*wight;
    }

    @Override
    public String toString() {
        return "长方形的长: "+lenght+",宽: "+wight;
    }
}
