import java.util.Objects;

public class Student {
    private String name;
    private int age;

    public int getAge() {
        return age;
    }


    public void setAge(int age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Student() {
    }

    public Student(String name, int age) {
        this.name = name;
        this.age = age;
    }
    //重写toString方法
    public String toString(){
        return "名字: "+name+"， 年龄： "+age;
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) return true;
        if (object == null || getClass() != object.getClass()) return false;
        Student student = (Student) object;
        return age == student.age && Objects.equals(name, student.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, age);
    }
//    //重写equals方法
//    public boolean equals(Object object){
//        //如果是同一个对象
//        if(this==object){
//            return true;
//        }
//        if (object instanceof Student student){
//            return this.name.equals(student.name)&&this.age==student.age;
//        }
//        return false;
//    }
}
