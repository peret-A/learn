package main.java;

public enum Gender {
    男,女
}
