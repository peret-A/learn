package main.java;

public class StudentTest {
    public static void main(String[] args) {
        Student student =new Student("小明",25,Gender.女);
        System.out.println(student);
    }
}
