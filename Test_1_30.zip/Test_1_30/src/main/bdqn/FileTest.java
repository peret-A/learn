package main.bdqn;

import java.io.File;
import java.io.IOException;

public class FileTest {
    public static void main(String[] args) throws IOException {
//        File file =new File("test.txt");
//        System.out.println(file.canExecute());
//        System.out.println(file.canRead());
//        File file1 = new File("ab.txt");
//        System.out.println(file1.canExecute());
//        System.out.println(file1.canRead());

        File file =new File("C:\\Users\\86156\\Desktop\\1月日历\\day23\\test.txt");
        System.out.println(file.exists());
        System.out.println(file.canExecute());
        System.out.println(file.canRead());
        System.out.println(file.isFile());
        File file1 =new File("C:\\Users\\86156\\Desktop\\1月日历\\day23\\test1.txt");
        System.out.println(file1.exists());
        System.out.println(file1.canExecute());
        System.out.println(file1.canRead());
        File file2 = new File("C:\\Users\\86156\\Desktop\\1月日历\\day23\\test");
        System.out.println(file2.isFile());
        System.out.println(file2.isDirectory());
        System.out.println(file.length());
        System.out.println(file.getPath());

        System.out.println(file1.delete());
        System.out.println(file.delete());
        System.out.println(file.delete());
        System.out.println(file.createNewFile());
        System.out.println(file.exists());

        System.out.println(file.getAbsoluteFile());
    }
}
