package main.bdqn;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class FileTest01 {
    public static void main(String[] args) throws IOException {
        File file =new File("ab.txt");
        System.out.println(file.exists());
        //创建文件
//        System.out.println(file.createNewFile());
//
//        System.out.println("绝对路径: "+file.getAbsoluteFile());
//        System.out.println("相对路径: "+file.getPath());
//
//        File file1 = new File("C:\\Users\\86156\\Desktop\\1月日历\\day23");
//        String[] strings =  file1.list();
//        for (String s: strings){
//            System.out.println(s);
//        }
//
//        File file2 =new File("知识要点_java.txt");
//        System.out.println(file2.getAbsoluteFile());
//        System.out.println(file2.exists());
//        System.out.println(file2.length());
//        File file3 =new File("C:\\Users\\86156\\Desktop\\1月日历\\day23\\Test\\知识要点_java.txt");
//        System.out.println(file2.exists());
//        System.out.println(file2.length());
    }
}
