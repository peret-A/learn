package main.bdqn;

import java.io.*;

public class FileTest04 {
    /**
     * 将D盘的student.txt文件 复制到C:\Users\86156\Desktop\1月日历\day23/worker.txt文件
     */
    public static void main(String[] args) throws IOException {
        //先读取文件数据
        File file =new File("D:\\student.txt");
        //判断文件是否存在，如果不存在就新建一个
        if(!file.exists()){
            file.createNewFile();
        }
        //创建输入文件
        File file1 =new File("C:\\Users\\86156\\Desktop\\1月日历\\day23/worker.txt");
        //写入方法不需要判断是否存在
        //创建FileInputStream类 FileOutputStream类
        FileInputStream fileInputStream =new FileInputStream(file);
        FileOutputStream fileOutputStream =new FileOutputStream(file1);
        //通过循环方法读写数据
        int num = 0;
    while ((num = fileInputStream.read())!=-1){
        fileOutputStream.write((char)num);
    }
    //关闭文建流
    fileOutputStream.close();
    fileInputStream.close();

    }
}
