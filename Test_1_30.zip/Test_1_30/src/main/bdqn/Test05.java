package main.bdqn;

import java.io.*;

public class Test05 {

    public static void main(String[] args) throws IOException {
        //准备文件
        File file =new File("ab.txt");
        //准备文件输入流
        InputStream inputStream =new FileInputStream(file);
        InputStreamReader inputStreamReader =new InputStreamReader(inputStream,"utf-8");
        //读取数据
        long num = file.length();
        char[] chars =new char[(int)num];
        for (int i = 0; i <num ; i++) {
            chars[i] = (char) inputStreamReader.read();
        }
        //遍历数据
        for(char c : chars){
            System.out.print(c);
        }
        //关闭流
        inputStreamReader.close();
        inputStream.close();

    }
}
