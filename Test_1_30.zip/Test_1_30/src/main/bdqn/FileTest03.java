package main.bdqn;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class FileTest03 {
    public static void main(String[] args) throws IOException {
        File file =new File("ab.txt");
        //创建文件输入流
        FileInputStream fileInputStream =new FileInputStream(file);
        //判断是否存在
        System.out.println(file.exists());
        //遍历
        //方式2
        byte[] bytes =new byte[1024];
        int num =fileInputStream.read(bytes);
        for (int i = 0; i < num; i++) {
            System.out.print((char) bytes[i]);
        }




    }
}
