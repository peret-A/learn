package main.bdqn;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.chrono.MinguoDate;

public class InputFile {
    public static void main(String[] args) throws IOException {
        File file =new File("ab.txt");
        System.out.println(file.exists());
        //创建文件输入流
        FileInputStream fileInputStream =new FileInputStream(file);
        System.out.println(fileInputStream.available());
//        int num1 = fileInputStream.read();
//        System.out.println(num1);
//
//        int num2 = fileInputStream.read();
//        System.out.println(num2);
//
//        int num3 = fileInputStream.read();
//        System.out.println(num3);
//
//        int num4 = fileInputStream.read();
//        System.out.println(num4);

//        //遍历
//        int index ;
//        do {
//            index = fileInputStream.read();
//            System.out.println(index);
//        }while (index  !=-1);

        //遍历
//        int num;
//        while ((num=fileInputStream.read())!=-1)
//        {
//            System.out.println(num);
//        }
        //遍历
        byte[] bytes =new byte[1024];
//        int num = FileInputStream.read();



        fileInputStream.close();
    }
}
