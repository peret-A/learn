package main.bdqn;

import java.io.File;

public class FileTest02 {
    public static void main(String[] args) {
//        File file =new File("C:\\Users\\86156\\Desktop\\1月日历\\day23/知识要点_java.txt");
//        System.out.println(file.exists());
//        System.out.println(file.length());
//        System.out.println(file.isFile());
//        System.out.println(file.isDirectory());
//        System.out.println(file.getAbsoluteFile());
//        System.out.println(file.getName());
//        File file1 =new File("知识要点_java.txt");
//        System.out.println(file1.exists());
//        System.out.println(file1.length());
//        System.out.println(file1.delete());
//        File file2 =new File("C:\\Users\\86156\\Desktop\\1月日历\\day23/test.txt");
//        System.out.println(file2.exists());
//        System.out.println(file2.delete());

        File file =new File("ab.txt");
        System.out.println(file.exists());
        File file1 =new File("知识要点_java.txt");
        System.out.println(file1.getAbsolutePath());
        System.out.println(file1.exists());
    }
}
