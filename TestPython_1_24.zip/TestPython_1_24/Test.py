# # 导包
# from pymysql import Connection
#
# # 创建链接数据库
# conn = Connection(
#     host='localhost',   #主机号
#     port=3306,          #端口号
#     user='root',        #用户名
#     password='123456',  #密码
#     autocommit=True     #设置自动提交
# )
#
# # 选择数据库
# conn.select_db('myss')
#
# # 创建游标对象
# cursor = conn.cursor()
#
# # 创建表
# cursor.execute("create table if not exists student10(name varchar(255),age int,gender varchar(1))")
#
# # # 插入数据
# # cursor.execute("insert into student10 values('小米',25,'男')")
# # cursor.execute("insert into student10 values('小明',26,'女')")
# # cursor.execute("insert into student10 values('小黑',28,'男')")
# # cursor.execute("insert into student10 values('小红',20,'男')")
#
# # # 查询数据 年龄小于26的
# # cursor.execute("select * from student10 where age<26")
# # # 将查询到的数据显示出来
# # print(cursor.fetchall())
# #
#
# # # 去重显示数据
# # cursor.execute("select distinct * from student10")
# # # 显示数据
# # print(cursor.fetchall())
#
# # 删除元素小米 第一个
# # cursor.execute("delete from student10 where name = '小米' ")
#
#
# # # 显示现有数据
# # cursor.execute("select * from student10")
# # print(cursor.fetchall())
#
# # 添加小米
# # cursor.execute("insert into student10 values('小米',25,'男')")
#
# # # 删除重复的
# # cursor.execute("delete from student10 where name = (select distinct from student10)")
#
#
#
# # 关闭链接
# conn.close()