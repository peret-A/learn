import java.util.Iterator;
import java.util.LinkedList;
import java.util.NoSuchElementException;

public class LinkedListTest {
    public static void main(String[] args) throws NoSuchElementException{
        //准备数据
        Student student =new Student("小明",25,"男");
        Student student1 =new Student("小红",25,"男");
        Student student2 =new Student("小爱",25,"男");
        Student student3 =new Student("小七",25,"男");
        //准备容器
        LinkedList<Student> studentLinkedList =new LinkedList<>();
        //插入数据
        studentLinkedList.add(student);
        studentLinkedList.add(student2);
        studentLinkedList.add(student3);
        studentLinkedList.add(student2);
        studentLinkedList.add(student1);
        studentLinkedList.addFirst(student3);
        studentLinkedList.addLast(student1);
        studentLinkedList.add(1,student1);
        studentLinkedList.add(student);

        //遍历数据
        for (var x:studentLinkedList){
            System.out.println(x);
        }
        System.out.println("------------------------");
        //浅拷贝
        LinkedList<Student> studentLinkedList1 = (LinkedList<Student>) studentLinkedList.clone();
        System.out.println(studentLinkedList1.toString());
        studentLinkedList1.clear();
        System.out.println(studentLinkedList1.isEmpty());
        System.out.println(studentLinkedList.size());

        System.out.println("----------------------------");
        //逆向迭代
        Iterator<Student> descendingIterator = studentLinkedList.descendingIterator();
        while (descendingIterator.hasNext()){
            System.out.println(descendingIterator.next());
        }
        System.out.println("---------------------");
        //正向遍历
        Iterator<Student> iterator = studentLinkedList.iterator();
        while (iterator.hasNext()){
            System.out.println(iterator.next());
        }

        //逆向
        System.out.println("-------------------");
        studentLinkedList.reversed();
        //遍历
        iterator = studentLinkedList.iterator();
        while (iterator.hasNext()){
            System.out.println(iterator.next());
        }
        //获取第一个元素
        Student student4 = studentLinkedList.element();
        System.out.println(student4);
        System.out.println(studentLinkedList.peek());
        System.out.println(studentLinkedList.poll());
        System.out.println(studentLinkedList.pop());
        studentLinkedList.push(student4);
        System.out.println(studentLinkedList.peek());

        studentLinkedList1.clear();
        System.out.println(studentLinkedList1.peek());
        try {
            System.out.println(studentLinkedList1.element());
        }catch (NoSuchElementException e){
            System.out.println(e);
//            throw new RuntimeException(e);
        }
        //python 的try catch else fainlly throws throw
        try {
            studentLinkedList1.pop();
        }catch (NoSuchElementException e){
            System.out.println(e);
//            throw new RuntimeException(e);
        }

        System.out.println(studentLinkedList1.poll());

        studentLinkedList.set(2,student4);
        Student[] students = (Student[]) studentLinkedList.toArray();

    }
}
