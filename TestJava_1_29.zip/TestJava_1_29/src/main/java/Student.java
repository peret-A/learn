public class Student extends Proson{
    private String gender;

    @Override
    public String toString() {
        return "Student{" +
                super.toString()
                +
                "gender='" + gender + '\'' +
                '}';
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Student(String name, int age, String gender) {
        super(name, age);
        this.gender = gender;
    }

    public Student(String gender) {
        this.gender = gender;
    }

    public Student() {
    }
}
