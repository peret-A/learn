import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class Test {
    public static void main(String[] args) {
        //准备数据
        Student student =new Student("小明",25,"男");
        Student student1 =new Student("小红",25,"男");
        Student student2 =new Student("小爱",25,"男");
        Student student3 =new Student("小七",25,"男");
        //准备容器
        ArrayList<Student> studentArrayList =new ArrayList<>();
        studentArrayList.add(student);
        studentArrayList.add(student2);
        studentArrayList.add(student3);
        studentArrayList.add(student);

        //遍历
        Iterator<Student> iterator = studentArrayList.iterator();
        while (iterator.hasNext()){
            System.out.println(iterator.next());
        }

        //clone() 浅拷贝即将值复制 而不是址复制
        ArrayList<Student> studentArrayList1 = (ArrayList<Student>) studentArrayList.clone();
        System.out.println(studentArrayList);
        System.out.println(studentArrayList1);
        studentArrayList1.remove(0);
        System.out.println(studentArrayList);
        System.out.println(studentArrayList1);
        studentArrayList.remove(1);
        System.out.println(studentArrayList);
        System.out.println(studentArrayList1);
        System.out.println(studentArrayList.contains(student));

        //查询
        System.out.println(studentArrayList);
        System.out.println(studentArrayList.toString());
    }
}
