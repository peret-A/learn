import java.util.*;

public class HashMapTest {
    public static void main(String[] args) {
        //准备数据
        Student student4 =new Student("小明",25,"男");
        Student student1 =new Student("小红",25,"男");
        Student student2 =new Student("小爱",25,"男");
        Student student3 =new Student("小七",25,"男");

        //准备容器
        HashMap<String ,Student> hashMap =new HashMap<>();

        //插入数据
        hashMap.put("小明",student4);
        hashMap.put("小红",student1);
        hashMap.put("小爱",student2);
        hashMap.put("小七",student3);
        hashMap.put("小七",student3);
        //遍历数据
        //获取所有keys
        Set<String> keys = hashMap.keySet();
        for (String key : keys){
            System.out.println(hashMap.get(key));
        }
        //获取所有的values
        Collection<Student> students =   hashMap.values();
        //遍历
        System.out.println("---------------------");
        Iterator<Student> iterator =students.iterator();
        while (iterator.hasNext()){
            System.out.println(iterator.next());
        }
        System.out.println(hashMap.remove("小明"));
        System.out.println("----------------------");
        //遍历数据
        //获取所有keys
        keys = hashMap.keySet();
        for (String key : keys){
            System.out.println(hashMap.get(key));
        }

        System.out.println("-------------------------");

        Set<Map.Entry<String,Student>> set = hashMap.entrySet();
        for (var x:set){
            System.out.println(set);
        }


//        Map.Entry<String,Student> me =new AbstractMap.SimpleEntry<>("小明",student4);
    }

}
