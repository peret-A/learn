package test;

import dao.User;
import dao.RegularUsers;

import java.util.Arrays;
import java.util.Scanner;

public class Enroll {
    public static void  enroll(User[] users){

        System.out.println("------------------------注册账号--------------------------");
        //如果最后一个人不是空就说明还有空 如果是空就将数组长度变长
        if(users[users.length-1].getTel()!=null){
            User[] user= Arrays.copyOf(users,users.length*2);
            for (int i = users.length; i < user.length; i++) {
                user[i]=new User();
            }
            users=user;
        }

        //输入手机号码 和 身份证号码 是唯一输入错误就退出
        //创建Scanner对象
        Scanner scanner=new Scanner(System.in);
        System.out.print("输入手机号码: ");
        String tel=scanner.next();

        int i;
        for (i = 0; i < users.length; i++) {
            if (users[i].getTel() != null && users[i].getTel().equals(tel)) {
                System.out.println("手机号码是已存在 退出注册");
                return;

            }
            if (users[i].getTel() == null) {
                break;
            }
        }
        System.out.print("输入身份证号码: ");
        String id =scanner.next();
        for (i = 0;  i<users.length ; i++) {
            if (users[i].getTel() != null && users[i].getId().equals(id)) {
                System.out.println("身份证号码是已存在 退出注册");
                return;
            }
            if (users[i].getTel() == null) {
                break;
            }
        }


        for (i = 0;  i< users.length; i++) {

            if(users[i].getTel()==null){
                //将User向下转型  变成普通用户
                users[i]=new RegularUsers();

                users[i].setTel(tel);
                users[i].setId(id);

                break;
        }

        }
        System.out.print("输入密码: ");
        users[i].setPwd(scanner.next());
        System.out.print("输入名字: ");
        users[i].setName(scanner.next());
        System.out.print("输入性别: ");
        users[i].setGender(scanner.next());
        System.out.print("输入专业: ");
        users[i].setDept(scanner.next());
        System.out.print("输入地址: ");
        users[i].setAdder(scanner.next());

    }
}
