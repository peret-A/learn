package test;

import dao.*;

import java.util.Arrays;
import java.util.Scanner;

public class Login {
    public static void login(User[] users, Book[] books, BorBook[] borBooks){
        System.out.println("------------------------登录账号--------------------------");
        //创建Scanner对象
        Scanner scanner=new Scanner(System.in);
        System.out.print("输入手机号码或者身份证号码: ");
        String num=scanner.next();
        System.out.print("输入密码: ");
        String pdw =scanner.next();
        int i;
        for (i = 0; i < users.length; i++) {
            if(users[i].getTel()==null){
                System.out.println("用户不存在,退出程序");
                return;
            }
            if(users[i].equals(num,num,pdw)){
                System.out.println("登录成功，欢迎回来: "+users[i].getName());
                break;
            }
        }
        if(i==users.length){
            System.out.println("用户名或者密码不正确");
            return;
        }
        //通过用户的是普通用户或者vip用户来判断进入页面
        if( users[i] instanceof VipUser){
            System.out.println("------------------------管理员页面--------------------------");

            int choose;
            //通过do while进入循环
            do {
                //管理员用户菜单
                Mean.userVipMean();
                System.out.print("输入选项: ");
                choose =scanner.nextInt();
                switch (choose){
                    case 0:
                        System.out.println("退出登录");
                        break;
                    case 1:
                        //查看所有图书
                        check(books);
                        break;
                    case 2:
                        //添加图书
                        addBook(books);
                        break;
                    case 3:
//                        修改图书
                        upDataBook(books);
                        break;
                    case 4:
                        //查看所有普通用户信息
                        checkUser(users);
                        break;
                    case 5:
                        //查看管理员账号信息
                        checkVipUser(users);
                        break;
                    case 6:
                        //修改管理员账号信息
                        upDataUser(users);
                        break;
                    default:
                        System.out.println("输入不符合选项,重新选择");
                        break;
                }
            }while (choose!=0);

        }else{
            System.out.println("------------------------普通用户页面--------------------------");
            int choose;
            //通过do while进入循环
            do {
                //普通用户菜单
                Mean.userMean();
                System.out.print("输入选项: ");
                choose =scanner.nextInt();
                switch (choose){
                    case 0:
                        System.out.println("退出登录");
                        break;
                    case 1:
                        //查看所有图书
                        check(books);
                        break;
                    case 2:
                        //借阅图书
                        borrowBook(users[i],books,borBooks);
                        break;
                    case 3:
                        //归还图书
                        backBook(borBooks);
                        break;
                    case 4:
                        //显示用户信息
                        showSelf(users[i]);
                        break;
                    case 5:
                        //修改用户信息
                        upDataSelf(users[i]);
                        break;
                    default:
                        System.out.println("输入不符合选项,重新选择");
                        break;
                }
            }while (choose!=0);

        }


    }

    private static void upDataSelf(User user) {
        //创建Scanner对象
        Scanner scanner=new Scanner(System.in);
        System.out.println("------------------------修改用户--------------------------");
        System.out.print("输入密码: ");
        user.setPwd(scanner.next());
        System.out.print("输入名字: ");
        user.setName(scanner.next());
        System.out.print("输入性别: ");
        user.setGender(scanner.next());
        System.out.print("输入专业: ");
        user.setDept(scanner.next());
        System.out.print("输入地址: ");
        user.setAdder(scanner.next());
        System.out.println("输入任意字符退出程序");
        String exit =scanner.next();
    }

    private static void showSelf(User user) {
        //创建Scanner对象
        Scanner scanner=new Scanner(System.in);
        System.out.println("------------------------显示信息--------------------------");
        System.out.println(user.toString());
        System.out.println("输入任意字符退出程序");
        String exit =scanner.next();
    }

    private static void backBook(BorBook[] borBooks) {
        System.out.println("------------------------归还图书--------------------------");
        //创建Scanner对象
        Scanner scanner=new Scanner(System.in);
        System.out.print("输入要归还的图书: ");
        String name =scanner.next();
        for (int i = 0; i < borBooks.length; i++) {
            if(name.equals(borBooks[i].getBookName())){
                //将图书状态变成已归还
                borBooks[i].setState("已归还");
                System.out.println("输入任意字符退出程序");
                String exit =scanner.next();
                return;
            }
        }
        System.out.println("找不到该图书,退出程序");

    }

    public static void check(Book[] books){
        System.out.println("------------------------查看图书--------------------------");
        for (int i = 0; i < books.length; i++) {
            if(books[i].getName()==null)
                return;
            System.out.println(books[i].toString());
        }
        //创建Scanner对象
        Scanner scanner =new Scanner(System.in);

        System.out.println("输入任意字符退出程序");
        String exit =scanner.next();
    }


    public static void addBook(Book[] books){
        System.out.println("------------------------添加图书--------------------------");
        //创建Scanner对象
        Scanner scanner=new Scanner(System.in);
        //添加时 如果图书库已满就需要扩充
        if(!(books[books.length-1].getName()==null)){
            Book[] book = Arrays.copyOf(books,books.length*2);
            for (int i = books.length; i < book.length; i++) {
                book[i]=new Book();
            }
            books=book;
        }
        int i;
        System.out.print("输入书名: ");
        String name =scanner.next();

        for (i = 0; i < books.length; i++) {
            if (books[i].getName()!=null&&name.equals(books[i].getName())){
                System.out.println("要添加的图书已存在");
                return;
            }else if(books[i].getName()==null){
                break;
            }

        }
        books[i].setName(name);
        System.out.print("输入数量: ");
        books[i].setNum(scanner.nextInt());


        System.out.println("输入任意字符退出程序");
        String exit =scanner.next();
    }


    public static void upDataBook(Book[] books){
        System.out.println("------------------------修改图书--------------------------");
        //创建Scanner
        Scanner scanner=new Scanner(System.in);
        System.out.print("输入要修改图书的名字: ");
        String name =scanner.next();
        for (int i = 0; i < books.length; i++) {
           if( books[i].getName().equals(name)){
               System.out.print("输入数量: ");
               books[i].setNum(scanner.nextInt());
               return;
           }
        }
        System.out.println("找不到要修改的图书,退出程序");


        System.out.println("输入任意字符退出程序");
        String exit =scanner.next();
    }


    public static void checkUser(User[] users){
        System.out.println("------------------------查看普通用户--------------------------");

        for (int i = 0; i < users.length; i++) {
            //如果是空就结束程序
            if(users[i].getTel()==null){
                return;
                //如果不是就判断是不是普通用户 如果是就打印出来
            }else if(users[i] instanceof RegularUsers){
                System.out.println(users[i].toString());
            }

        }
        //创建Scanner对象
        Scanner scanner =new Scanner(System.in);

        System.out.println("输入任意字符退出程序");
        String exit =scanner.next();
    }

    public static void checkVipUser(User[] users){
        System.out.println("------------------------查看管理员用户--------------------------");

        for (int i = 0; i < users.length; i++) {
            //如果是空就结束程序
            if(users[i].getTel()==null){
                return;
                //如果不是就判断是不是管理员用户 如果是就打印出来
            }else if(users[i] instanceof VipUser){
                System.out.println(users[i].toString());
            }

        }
        //创建Scanner对象
        Scanner scanner =new Scanner(System.in);

        System.out.println("输入任意字符退出程序");
        String exit =scanner.next();
    }
    public static void upDataUser(User[] users){
        System.out.println("------------------------修改全部用户--------------------------");
        //创建Scanner对象
        Scanner scanner=new Scanner(System.in);
        System.out.print("输入要修改的用户名: ");
        String root=scanner.next();
        int i;
        for (i = 0; i < users.length; i++) {
            if(users[i].getName()==null){
                System.out.println("要修改的用户不存在");
                return;
            }
            if(root.equals(users[i].getTel())||root.equals(users[i].getId())){
                break;
            }
        }
        System.out.print("输入密码: ");
        users[i].setPwd(scanner.next());
        System.out.print("输入名字: ");
        users[i].setName(scanner.next());
        System.out.print("输入性别: ");
        users[i].setGender(scanner.next());
        System.out.print("输入专业: ");
        users[i].setDept(scanner.next());
        System.out.print("输入地址: ");
        users[i].setAdder(scanner.next());
        System.out.print("输入变成管理员还是普通用户(管理员/普通用户): ");
        String name=scanner.next();
        if(name.equals("管理员")){
            //先向上转换
            users[i]=new User(users[i]);
            //再向下转换
            users[i]=new VipUser(users[i]);
        }else if(!(name.equals("root"))&&name.equals("普通用户")){
            //先向上转换
            users[i]=new User(users[i]);
            //再向下转换
            users[i]=new RegularUsers(users[i]);
        }


        System.out.println("输入任意字符退出程序");
        String exit =scanner.next();
    }

    public static void borrowBook(User user, Book[] books, BorBook[] borBooks){
        System.out.println("------------------------借阅书籍--------------------------");
        //打印借阅书单
        for (int i = 0; i < borBooks.length; i++) {
            if(borBooks[i].getBookName()==null){
                break;
            }
            System.out.println(Arrays.toString(borBooks));
        }

        //创建Scanner对象
        Scanner scanner=new Scanner(System.in);
        System.out.print("输入要借阅的书籍: ");
        String name=scanner.next();
        for (int i = 0; i < books.length; i++) {
            if(name.equals(books[i].getName())){
                //如果找到了就将书籍存入借阅书籍
                borBooks[i].setBookName(name);
                borBooks[i].setUserName(user.getName());
                System.out.print("输入要借阅的天数: ");
                borBooks[i].setDays(scanner.nextInt());
                borBooks[i].setState("借阅中");
            }
        }

        System.out.println("输入任意字符退出程序");
        String exit =scanner.next();
    }
}
