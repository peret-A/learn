package test;

/**
 *  * 	2）启动系统后，显示登录账号、注册账号、退出登录三个模块
 *  * 		登录账号：
 *  * 			显示管理员登录、用户登录两个模块
 *  * 		注册账号：
 *  * 			显示注册管理员、注册用户两个模块
 *  * 		退出登录：
 *  * 			结束程序运行
 *  *
 *  * 	3）登录账号成功后，根据账号的性质来显示不同的模块：
 *  * 		登录普通账号成功后，显示如下模块：
 *  * 			--》查看所有图书，图书显示哪些信息，你自行设计
 *  * 			--》借阅图书
 *  * 			--》归还图书
 *  * 			--》显示用户信息（只能查看自己的用户信息）
 *  * 			--》修改用户信息（只能修改自己的用户信息）
 *  * 			--》退出系统
 *  * 		登录管理员账号成功后，显示如下模块：
 *  * 			--》查看所有图书，图书显示哪些信息，你自行设计
 *  * 			--》添加图书
 *  * 			--》修改图书
 *  * 			--》删除图书
 *  * 			--》查看所有普通用户信息
 *  * 			--》查看管理员账号信息
 *  * 			--》修改管理员账号信息
 *  * 			--》退出系统
 */
public class Mean {
    public static void mean(){
        /*
        2）启动系统后，显示登录账号、注册账号、退出登录三个模块
         */
        System.out.println("------------------------主菜单--------------------------");
        System.out.println("1 .  登录账号");
        System.out.println("2 .  注册账号");
        System.out.println("0 .  退出登录");
    }

    public static void userMean(){
        System.out.println("------------------------用户菜单--------------------------");
        System.out.println("1. 查看所有图书");
        System.out.println("2. 借阅图书");
        System.out.println("3. 归还图书");
        System.out.println("4. 显示用户信息");
        System.out.println("5. 修改用户信息");
        System.out.println("0. 退出系统");
    }

    public static void  userVipMean(){
        System.out.println("------------------------管理员用户菜单--------------------------");
        System.out.println("1. 查看所有图书");
        System.out.println("2. 添加图书");
        System.out.println("3. 修改图书");
        System.out.println("4. 查看所有普通用户信息");
        System.out.println("5. 查看管理员账号信息");
        System.out.println("6. 修改管理员账号信息");
        System.out.println("0. 退出系统");
    }
}
