package test;

import dao.Book;
import dao.User;
import dao.BorBook;
import dao.VipUser;

public class Init {
    public static void Init(User[] users, Book[] books, BorBook[] borBooks){
        //对开辟空间的 进行初始化
        //设置一个初始管理员
        users[0] =new VipUser();
        users[0].setTel("root");
        users[0].setId("root");
        users[0].setPwd("123");
        users[0].setName("管理员");
        for (int i = 1; i < users.length; i++) {
            users[i]=new User();
        }

        //设置一个初始化书籍
        books[0] =new Book("奥特曼大战小怪兽",2);
        books[1] =new Book("安徒生通童话",4);
        for (int i = 2; i < books.length; i++) {
            books[i]=new Book();
        }

        //设置一个初始化借阅书籍
        for (int i = 0; i < borBooks.length; i++) {
           borBooks[i]=new BorBook();
        }
    }
}
