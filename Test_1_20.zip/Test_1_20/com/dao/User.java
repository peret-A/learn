package dao;

import java.util.Objects;

public class User {
    //管理员账号和普通账号除了手机号码、身份中号码、密码三个数据之外，还有姓名、性别、专业、住址信息
    private String tel;
    private String id;
    private String pwd;
    private String name;
    private String gender;
    private String dept;
    private String adder;

    public User(User user) {
        this.setTel(user.getTel());
        this.setId(user.getId());
        this.setPwd(user.getPwd());
        this.setName(user.getName());
        this.setGender(user.getGender());
        this.setDept(user.getDept());
        this.setAdder(user.getAdder());
    }


    public boolean equals(String tel,String id,String pdw) {
        return (this.getTel().equals(tel) || this.getId().equals(id))&&this.getPwd().equals(pdw);
    }



    @Override
    public String toString() {
        return "普通用户{" +
                "手机号码='" + tel + '\'' +
                ", 身份证号码='" + id + '\'' +
                ", 密码='" + pwd + '\'' +
                ", 名字='" + name + '\'' +
                ", 性别=" + gender +
                ", 专业='" + dept + '\'' +
                ", 地址='" + adder + '\'' +
                '}';
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public String getAdder() {
        return adder;
    }

    public void setAdder(String adder) {
        this.adder = adder;
    }

    public User() {
    }

    public User(String tel, String id, String pwd, String name, String gender, String dept, String adder) {
        this.tel = tel;
        this.id = id;
        this.pwd = pwd;
        this.name = name;
        this.gender = gender;
        this.dept = dept;
        this.adder = adder;
    }
}
