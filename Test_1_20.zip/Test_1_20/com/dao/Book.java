package dao;

public class Book {
    // 图书名字 数量
    private String name;
    private int num;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public Book() {
    }

    public Book(String name, int num) {
        this.name = name;
        this.num = num;
    }

    @Override
    public String toString() {
        return "书籍{" +
                "名字='" + name + '\'' +
                ", 数量=" + num +
                '}';
    }

    public boolean equals(String name){
        return this.getName().equals(name);
    }
}
