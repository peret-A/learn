package dao;

public class BorBook {
    //借阅名字 借阅人 借阅时间  借阅状态
    private String bookName;
    private String userName;

    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public int getDays() {
        return days;
    }

    public void setDays(int days) {
        this.days = days;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public BorBook() {
    }

    @Override
    public String toString() {
        return "借阅书单{" +
                "借阅书名='" + bookName + '\'' +
                ", 借阅人='" + userName + '\'' +
                ", 借阅天数=" + days +
                ", 借阅状态='" + state + '\'' +
                '}';
    }

    public BorBook(String bookName, String userName, int days, String state) {
        this.bookName = bookName;
        this.userName = userName;
        this.days = days;
        this.state = state;
    }

    private int days;
    private String state;


}
