package dao;

public class RegularUsers extends User{
    //普通用户

    public RegularUsers(String tel, String id, String pwd, String name, String gender, String dept, String adder) {
        super(tel, id, pwd, name, gender, dept, adder);
    }

    public RegularUsers() {

    }

    public RegularUsers(User user) {
        this.setTel(user.getTel());
        this.setId(user.getId());
        this.setPwd(user.getPwd());
        this.setName(user.getName());
        this.setGender(user.getGender());
        this.setDept(user.getDept());
        this.setAdder(user.getAdder());
    }
}
