package dao;

public class VipUser extends User{
    //管理者用户
    public VipUser(String tel, String id, String pwd, String name, String gender, String dept, String adder) {
        super(tel, id, pwd, name, gender, dept, adder);
    }

    public VipUser() {
    }

    @Override
    public String toString() {
        return "管理员用户{" +
                "手机号码='" + this.getTel() + '\'' +
                ", 身份证号码='" + this.getId() + '\'' +
                ", 密码='" + this.getPwd() + '\'' +
                ", 名字='" + this.getName() + '\'' +
                ", 性别=" + this.getGender() +
                ", 专业='" + this.getDept() + '\'' +
                ", 地址='" + this.getAdder() + '\'' +
                '}';
    }

    public VipUser(User user) {
        this.setTel(user.getTel());
        this.setId(user.getId());
        this.setPwd(user.getPwd());
        this.setName(user.getName());
        this.setGender(user.getGender());
        this.setDept(user.getDept());
        this.setAdder(user.getAdder());
    }
}
