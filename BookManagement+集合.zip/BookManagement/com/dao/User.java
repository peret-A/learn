package dao;

import java.util.Objects;

public class User {
    //管理员账号和普通账号除了手机号码、身份中号码、密码三个数据之外，还有姓名、性别、专业、住址信息
    private int tel;
    private int id;
    private int pwd;
    private String name;
    private String gender;
    private String dept;
    private String adder;


    public boolean equals(int num ,int pwd) {
        return (this.tel == num || this.id == num) && this.pwd == pwd;
    }

    @Override
    public int hashCode() {
        return Objects.hash(tel, id, pwd);
    }

    @Override
    public String toString() {
        return "User{" +
                "tel=" + tel +
                ", id=" + id +
                ", pwd=" + pwd +
                ", name='" + name + '\'' +
                ", gender='" + gender + '\'' +
                ", dept='" + dept + '\'' +
                ", adder='" + adder + '\'' +
                '}';
    }

    public int getTel() {
        return tel;
    }

    public void setTel(int tel) {
        this.tel = tel;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPwd() {
        return pwd;
    }

    public void setPwd(int pwd) {
        this.pwd = pwd;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public String getAdder() {
        return adder;
    }

    public void setAdder(String adder) {
        this.adder = adder;
    }

    public User() {
    }

    public User(int tel, int id, int pwd, String name) {
        this.tel = tel;
        this.id = id;
        this.pwd = pwd;
        this.name = name;
    }

    public User(int tel, int id, int pwd, String name, String gender, String dept, String adder) {
        this.tel = tel;
        this.id = id;
        this.pwd = pwd;
        this.name = name;
        this.gender = gender;
        this.dept = dept;
        this.adder = adder;
    }

    public User(User user) {
        this.tel = user.getTel();
        this.id = user.getId();
        this.pwd = user.getPwd();
        this.name = user.getName();
        this.gender = user.getGender();
        this.dept = user.getDept();
        this.adder = user.getAdder();
    }
}

