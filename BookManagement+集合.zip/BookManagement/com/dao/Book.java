package dao;

public class Book {
    // 图书名字 数量 出版社 位置
    private String name;
    private int num;
    private String publisher;
    private String adder;

    @Override
    public String toString() {
        return "书单{" +
                "书名='" + name + '\'' +
                ", 数量=" + num +
                ", 出版社='" + publisher + '\'' +
                ", 位置='" + adder + '\'' +
                '}';
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getAdder() {
        return adder;
    }

    public void setAdder(String adder) {
        this.adder = adder;
    }

    public Book() {
    }

    public Book(String name, int num, String publisher, String adder) {
        this.name = name;
        this.num = num;
        this.publisher = publisher;
        this.adder = adder;
    }
}
