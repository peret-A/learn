package test;

import dao.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Scanner;

public class Login {
    public static void login(ArrayList<User> userArrayList, ArrayList<Book> bookArrayList, ArrayList<BorBook> borBookArrayList) throws InterruptedException {
        System.out.println("------------------------登录账号--------------------------");
        //创建Scanner对象
        Scanner scanner=new Scanner(System.in);
        System.out.print("输入手机号码或者身份证号码: ");
        String num=scanner.next();
        System.out.print("输入密码: ");
        String pdw =scanner.next();
        //转变成int型
        int numInteger = Integer.parseInt(num);
        int pwdInteger = Integer.parseInt(pdw);
        //遍历
        int i;
        for (i=0; i<userArrayList.size();i++){
            if(userArrayList.get(i).equals(numInteger,pwdInteger))
                break;
        }

        //通过用户的是普通用户或者vip用户来判断进入页面
        if(userArrayList.get(i) instanceof VipUser){
            adminPage(userArrayList,bookArrayList);
        }else if(userArrayList.get(i) instanceof RegularUsers){
            userPage(userArrayList.get(i),bookArrayList,borBookArrayList);
        }

    }

    public static void adminPage(ArrayList<User> userArrayList,ArrayList<Book> bookArrayList) throws InterruptedException {
        System.out.println("------------------------管理员页面--------------------------");
        //创建Scanner对象
        Scanner scanner =new Scanner(System.in);

        int choose;
        //通过do while进入循环
        do {
            //管理员用户菜单
            Mean.userVipMean();
            System.out.print("输入选项: ");
            choose =scanner.nextInt();
            switch (choose){
                case 0:
                    System.out.println("退出登录");
                    break;
                case 1:
                    //查看所有图书
                    checkBook(bookArrayList);
                    break;
                case 2:
                    //添加图书
                    addBook(bookArrayList);
                    break;
                case 3:
                    // 修改图书
                    upDataBook(bookArrayList);
                    break;
                case 4:
                    //查看所有普通用户信息
                    checkUser(userArrayList);
                    break;
                case 5:
                    //查看管理员账号信息
                    checkVipUser(userArrayList);
                    break;
                case 6:
                    //修改管理员账号信息
                    upDataUser(userArrayList);
                    break;
                default:
                    System.out.println("输入不符合选项,重新选择");
                    break;
            }
        }while (choose!=0);
    }


    public static void userPage(User user,ArrayList<Book> bookArrayList,ArrayList<BorBook> borBookArrayList)  throws InterruptedException {
        System.out.println("------------------------普通用户页面--------------------------");
        //创建Scanner对象
        Scanner scanner =new Scanner(System.in);
        int choose;
        //通过do while进入循环
        do {
            //普通用户菜单
            Mean.userMean();
            System.out.print("输入选项: ");
            choose =scanner.nextInt();
            switch (choose){
                case 0:
                    System.out.println("退出登录");
                    break;
                case 1:
                    //查看所有图书
                    checkBook(bookArrayList);
                    break;
                case 2:
                    //借阅图书
                    borrowBook(user,bookArrayList,borBookArrayList);
                    break;
                case 3:
                    //查看所有借阅书单
                    checkBorBook(user,borBookArrayList);
                    break;
                case 4:
                    //归还图书
                    backBook(user,bookArrayList,borBookArrayList);
                    break;
                case 5:
                    //显示用户信息
                    showSelf(user);
                    break;
                case 6:
                    //修改用户信息
                    upDataSelf(user);
                    break;
                default:
                    System.out.println("输入不符合选项,重新选择");
                    break;
            }
        }while (choose!=0);
    }

    private static void upDataSelf(User user) throws InterruptedException {
        //创建Scanner对象
        Scanner scanner=new Scanner(System.in);
        System.out.println("------------------------修改用户--------------------------");
        System.out.print("输入密码: ");
        user.setPwd(scanner.nextInt());
        System.out.print("输入名字: ");
        user.setName(scanner.next());
        System.out.print("输入性别: ");
        user.setGender(scanner.next());
        System.out.print("输入专业: ");
        user.setDept(scanner.next());
        System.out.print("输入地址: ");
        user.setAdder(scanner.next());
        Thread.sleep(1000);
    }

    private static void showSelf(User user) throws InterruptedException {
        //创建Scanner对象
        Scanner scanner=new Scanner(System.in);
        System.out.println("------------------------显示信息--------------------------");
        System.out.println(user.toString());
        Thread.sleep(1000);
    }

    private static void backBook(User user ,ArrayList<Book> bookArrayList,ArrayList<BorBook> borBookArrayList) throws InterruptedException {
        System.out.println("------------------------归还图书--------------------------");
        //借阅书单
        for (BorBook borBook : borBookArrayList){
            System.out.println(borBook.toString());
        }
        //创建Scanner对象
        Scanner scanner=new Scanner(System.in);
        System.out.print("输入要归还的图书: ");
        String name =scanner.next();
        for(int i=0;i< borBookArrayList.size();i++){
            //如果书名与人名都匹配就归还
            if(name.equals(borBookArrayList.get(i).getBookName()) && user.getName().equals(borBookArrayList.get(i).getUserName())){
                borBookArrayList.get(i).setState("已归还");
                return;
            }
        }
        System.out.println("找不到该图书,退出程序");
        Thread.sleep(1000);
    }

    public static void checkBook(ArrayList<Book> bookArrayList) throws InterruptedException {
        System.out.println("------------------------查看图书--------------------------");
        //遍历
        for (Book book:bookArrayList){
            System.out.println(book.toString());
        }

        Thread.sleep(1000);
    }

    public static void checkBorBook(User user,ArrayList<BorBook> borBookArrayList) throws InterruptedException {
        System.out.println("------------------------查看图书--------------------------");
        //遍历
        for (BorBook borBook:borBookArrayList){
           if(user.getName().equals(borBook.getUserName())){
               System.out.println(borBook);
           }
        }

        Thread.sleep(1000);
    }


    public static void addBook(ArrayList<Book> bookArrayList) throws InterruptedException {
        System.out.println("------------------------添加图书--------------------------");
        //创建Scanner对象
        Scanner scanner=new Scanner(System.in);
        //判断添加的书是否已存在
        int i;
        System.out.print("输入书名: ");
        String name =scanner.next();
        for (Book book:bookArrayList){
            if(name.equals(book.getName())){
                System.out.println("该书已存在");
                return;
            }
        }
        System.out.print("输入数量: ");
        int num =scanner.nextInt();
        System.out.print("输入出版社: ");
        String publisher = scanner.next();
        System.out.print("输入地址: ");
        String adder = scanner.next();
        Book book=new Book(name,num,publisher,adder);
        //插入书籍
        bookArrayList.add(book);


        Thread.sleep(1000);
    }


    public static void upDataBook(ArrayList<Book> bookArrayList) throws InterruptedException {
        System.out.println("------------------------修改图书--------------------------");
        //创建Scanner
        Scanner scanner=new Scanner(System.in);
        System.out.print("输入要修改图书的名字: ");
        String name =scanner.next();
        //查找图书
        for (Book book:bookArrayList){
            if(name.equals(book.getName())){
                System.out.print("输入数量: ");
                book.setNum(scanner.nextInt());
                System.out.print("输入出版社: ");
                book.setPublisher(scanner.next());
                System.out.print("输入地址: ");
                book.setAdder(scanner.next());
                Thread.sleep(1000);

                return;
            }
        }

        System.out.println("该书不存在");
        Thread.sleep(1000);
    }


    public static void checkUser(ArrayList<User> userArrayList) throws InterruptedException {
        System.out.println("------------------------查看普通用户--------------------------");

        for (int i=0 ;i<userArrayList.size();i++){
            if(userArrayList.get(i) instanceof RegularUsers regularUsers){
                System.out.println(regularUsers);
            }
        }

        Thread.sleep(1000);
    }

    public static void checkVipUser(ArrayList<User> userArrayList) throws InterruptedException {
        System.out.println("------------------------查看管理员用户--------------------------");

        for (int i=0 ;i<userArrayList.size();i++){
            if(userArrayList.get(i) instanceof VipUser vipUser){
                System.out.println(vipUser);
            }
        }


        Thread.sleep(1000);
    }
    public static void upDataUser(ArrayList<User> userArrayList) throws InterruptedException {
        System.out.println("------------------------修改用户--------------------------");
        //创建Scanner对象
        Scanner scanner=new Scanner(System.in);
        System.out.print("输入要修改的名字: ");
        String root=scanner.next();
        int i;

        for(i =0;i < userArrayList.size();i++){
            if(root.equals(userArrayList.get(i).getName())){
                break;
            }
        }
        if(i==userArrayList.size()){
            System.out.println("未找到要修改的用户名");
            return;
        }
        System.out.print("输入密码: ");
        userArrayList.get(i).setPwd(scanner.nextInt());
        System.out.print("输入性别: ");
        userArrayList.get(i).setGender(scanner.next());
        System.out.print("输入专业: ");
        userArrayList.get(i).setDept(scanner.next());
        System.out.print("输入地址: ");
        userArrayList.get(i).setAdder(scanner.next());
        System.out.print("输入变成管理员还是普通用户(管理员/普通用户): ");
        String name=scanner.next();
        if(name.equals("管理员") && userArrayList.get(i) instanceof  RegularUsers){

           VipUser vipUser = new VipUser(userArrayList.get(i));
           userArrayList.remove(i);
           userArrayList.add(i,vipUser);
        }else if(!(name.equals("root"))&&name.equals("普通用户") && userArrayList.get(i) instanceof  VipUser){
            RegularUsers regularUsers =new RegularUsers(userArrayList.get(i));
            userArrayList.remove(i);
            userArrayList.add(i,regularUsers);
        }


        Thread.sleep(1000);
    }

    public static void borrowBook(User user, ArrayList<Book> bookArrayList, ArrayList<BorBook> borBookArrayList) throws InterruptedException {
        System.out.println("------------------------借阅书籍--------------------------");
        //打印借阅书单
        System.out.println("--图书库--");
        for (Book book : bookArrayList){
            System.out.println(book.toString());
        }
        //创建Scanner对象
        Scanner scanner=new Scanner(System.in);
        System.out.print("输入要借阅的书籍: ");
        String name=scanner.next();
        int i;
       for (i=0;i<bookArrayList.size();i++){
           if(name.equals(bookArrayList.get(i).getName())){
               //找到书了先判断数量是否为0如果为0就不能借添加到借阅书单
               if(bookArrayList.get(i).getNum()==0){
                   System.out.println("该书现有都被借阅中，请日后再来");
                   break;
               }
               //说明数量起码为1
               bookArrayList.get(i).setNum(bookArrayList.get(i).getNum()-1);
               //借阅书籍
               System.out.print("输入要借阅的天数: ");
               BorBook borBook =new BorBook(name,user.getName(),scanner.nextInt(),"借阅中");
               borBookArrayList.add(borBook);
               break;

           }
       }
        if(i==bookArrayList.size()){
            System.out.println("该书不存在");
        }
        Thread.sleep(1000);
    }
}
