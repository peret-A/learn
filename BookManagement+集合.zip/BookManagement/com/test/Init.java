package test;

import dao.Book;
import dao.User;
import dao.BorBook;
import dao.VipUser;

import java.util.ArrayList;

public class Init {
    public static void Init(ArrayList<User> userArrayList,ArrayList<Book> bookArrayList, ArrayList<BorBook> borBookArrayList){
        //对开辟空间的 进行初始化
        //设置一个初始管理员
        //将其向下转换
        VipUser vipUser =new VipUser(123,123,123,"root");
        userArrayList.add(vipUser);
        //设置一个初始化书籍
        Book book1 =new Book("奥特曼大战小怪兽",2,"上海译文出版社","2-311");
        Book book2 =new Book("安徒生通童话",4,"上海译文出版社","1-311");
        bookArrayList.add(book1);
        bookArrayList.add(book2);

        //设置一个初始化借阅书籍
        BorBook borBook =new BorBook("奥特曼大战小怪兽","root",5,"已归还");
        borBookArrayList.add(borBook);
    }
}
