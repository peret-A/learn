package test;

import dao.User;
import dao.RegularUsers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Scanner;

public class Enroll {
    public static void  enroll(ArrayList<User> userArrayList){

        System.out.println("------------------------注册账号--------------------------");

        //输入手机号码 和 身份证号码 是唯一输入错误就退出
        //创建Scanner对象
        Scanner scanner=new Scanner(System.in);
        System.out.print("输入手机号码: ");
        String tel=scanner.next();
        //转变成int型
        int telInteger = Integer.parseInt(tel);
        //遍历
        Iterator<User> iterator = userArrayList.iterator();
        while (iterator.hasNext()){
            if(telInteger==iterator.next().getTel()){
                System.out.println("手机号码已存在，重新输入");
                return;
            }
        }
        System.out.print("输入身份证号码: ");
        String id=scanner.next();
        //转变成int型
        int idInteger = Integer.parseInt(id);
        //遍历
        iterator = userArrayList.iterator();
        while (iterator.hasNext()){
            if(idInteger==iterator.next().getId()){
                System.out.println("身份证号码已存在，重新输入");
                return;
            }
        }
        System.out.print("输入密码: ");
        String pwd=scanner.next();
        //转变成int型
        int pwdInteger = Integer.parseInt(pwd);
        System.out.print("输入名字: ");
        String name =scanner.next();
        System.out.print("输入性别: ");
        String gender = scanner.next();
        System.out.print("输入专业: ");
        String dept = scanner.next();
        System.out.print("输入地址: ");
        String adder = scanner.next();
        RegularUsers regularUsers =new RegularUsers(telInteger,idInteger,pwdInteger,name,gender,dept,adder);


        //插入数据
        userArrayList.add(regularUsers);


    }
}
